<!DOCTYPE html>
<html lang="<?php echo esc_attr( get_bloginfo( 'language' ) ); ?>">
<head>
<meta charset="UTF-8">
<title><?php echo esc_html( sprintf( __( 'Certificate — %s', 'fg-lms' ), $course->post_title ?? '' ) ); ?></title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }

body {
    font-family: Georgia, 'Times New Roman', serif;
    background: #f8f8f8;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    padding: 40px 20px;
}

.cert-outer {
    width: 900px;
    max-width: 100%;
}

.cert-wrap {
    background: #fff;
    border: 6px solid <?php echo $primary; ?>;
    border-radius: 4px;
    padding: 60px 70px;
    position: relative;
    box-shadow: 0 8px 40px rgba(0,0,0,.12);
    text-align: center;
}

/* Corner ornaments */
.cert-wrap::before,
.cert-wrap::after {
    content: '';
    position: absolute;
    width: 60px;
    height: 60px;
    border: 3px solid <?php echo $primary; ?>;
}
.cert-wrap::before { top: 10px; left: 10px; border-right: none; border-bottom: none; }
.cert-wrap::after  { bottom: 10px; right: 10px; border-left: none; border-top: none; }

.cert-logo {
    margin-bottom: 20px;
}
.cert-logo img {
    max-height: 70px;
    object-fit: contain;
}

.cert-overline {
    font-family: 'Helvetica Neue', Arial, sans-serif;
    font-size: 12px;
    letter-spacing: 4px;
    text-transform: uppercase;
    color: #888;
    margin-bottom: 12px;
}

.cert-title {
    font-size: 42px;
    font-weight: 700;
    color: <?php echo $primary; ?>;
    margin-bottom: 18px;
    letter-spacing: -1px;
}

.cert-presented {
    font-size: 15px;
    color: #555;
    margin-bottom: 10px;
}

.cert-name {
    font-size: 34px;
    font-weight: 700;
    color: #111;
    border-bottom: 2px solid <?php echo $primary; ?>;
    display: inline-block;
    padding-bottom: 4px;
    margin-bottom: 20px;
}

.cert-body {
    font-size: 16px;
    color: #444;
    line-height: 1.7;
    max-width: 640px;
    margin: 0 auto 30px;
}

.cert-course-name {
    font-size: 22px;
    font-weight: 700;
    color: #111;
    font-style: italic;
}

.cert-meta {
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #e8e8e8;
}

.cert-signature {
    text-align: left;
}
.cert-signature .sig-line {
    width: 200px;
    border-bottom: 1px solid #333;
    margin-bottom: 6px;
}
.cert-signature .sig-name  { font-weight: 700; font-size: 14px; }
.cert-signature .sig-title { font-size: 12px; color: #888; }

.cert-number-block {
    text-align: right;
}
.cert-number-block .cert-number-label {
    font-size: 10px;
    letter-spacing: 2px;
    text-transform: uppercase;
    color: #bbb;
    margin-bottom: 4px;
}
.cert-number-block .cert-number {
    font-size: 13px;
    font-family: monospace;
    color: #555;
}

.cert-date-block {
    text-align: center;
}
.cert-date-block .cert-date-label {
    font-size: 11px;
    color: #aaa;
    text-transform: uppercase;
    letter-spacing: 2px;
    margin-bottom: 4px;
}
.cert-date-block .cert-date {
    font-size: 15px;
    font-weight: 600;
    color: #333;
}

.cert-brand-footer {
    font-family: 'Helvetica Neue', Arial, sans-serif;
    font-size: 11px;
    color: #ccc;
    margin-top: 30px;
    letter-spacing: 1px;
}

.cert-seal {
    width: 80px;
    height: 80px;
    border: 4px solid <?php echo $primary; ?>;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
    color: <?php echo $primary; ?>;
    font-size: 36px;
}

@media print {
    body { background: #fff; padding: 0; }
    .cert-outer { width: 100%; }
    .cert-wrap { box-shadow: none; border-width: 4px; }
    .cert-print-btn { display: none !important; }
}
</style>
</head>
<body>
<div class="cert-outer">
    <div class="cert-wrap">

        <?php if ( $logo_url ) : ?>
        <div class="cert-logo">
            <img src="<?php echo $logo_url; ?>" alt="<?php echo esc_attr( $brand_name ); ?>">
        </div>
        <?php else : ?>
        <div class="cert-seal">&#9733;</div>
        <?php endif; ?>

        <p class="cert-overline"><?php esc_html_e( 'Certificate of Completion', 'fg-lms' ); ?></p>
        <h1 class="cert-title"><?php echo $brand_name; ?></h1>

        <p class="cert-presented"><?php esc_html_e( 'This certificate is proudly presented to', 'fg-lms' ); ?></p>
        <div class="cert-name"><?php echo esc_html( $user->display_name ); ?></div>

        <p class="cert-body">
            <?php esc_html_e( 'for the successful completion of the course', 'fg-lms' ); ?><br>
            <span class="cert-course-name"><?php echo esc_html( $course->post_title ); ?></span>
        </p>

        <div class="cert-meta">
            <!-- Signatory -->
            <div class="cert-signature">
                <div class="sig-line"></div>
                <div class="sig-name"><?php echo $signatory ?: esc_html( get_bloginfo( 'name' ) ); ?></div>
                <div class="sig-title"><?php echo $sign_title ?: $brand_name; ?></div>
            </div>

            <!-- Date -->
            <div class="cert-date-block">
                <div class="cert-date-label"><?php esc_html_e( 'Date Issued', 'fg-lms' ); ?></div>
                <div class="cert-date"><?php echo esc_html( $issued_date ); ?></div>
            </div>

            <!-- Certificate number -->
            <div class="cert-number-block">
                <div class="cert-number-label"><?php esc_html_e( 'Certificate No.', 'fg-lms' ); ?></div>
                <div class="cert-number"><?php echo esc_html( $cert->certificate_number ); ?></div>
            </div>
        </div>

        <p class="cert-brand-footer"><?php echo esc_html( strtoupper( $brand_name ) ); ?></p>
    </div>

    <div style="text-align:center;margin-top:20px">
        <button class="cert-print-btn" onclick="window.print()" style="
            background:<?php echo esc_attr( get_option('fg_lms_primary_color','#C8102E') ); ?>;
            color:#fff;border:none;padding:12px 28px;font-size:15px;
            border-radius:4px;cursor:pointer;font-family:Arial,sans-serif">
            🖨 <?php esc_html_e( 'Print Certificate', 'fg-lms' ); ?>
        </button>
    </div>
</div>
</body>
</html>
