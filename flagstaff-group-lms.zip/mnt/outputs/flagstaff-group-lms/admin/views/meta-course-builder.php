<?php
/**
 * Course Builder meta box — drag-and-drop lesson ordering.
 *
 * @var WP_Post $post
 * @var int[]   $lesson_order
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

// Get all lessons and quizzes associated with this course.
$lessons = get_posts( [
    'post_type'      => [ 'fg_lesson', 'fg_quiz' ],
    'meta_key'       => '_fg_lms_course_id',
    'meta_value'     => $post->ID,
    'post_status'    => [ 'publish', 'draft' ],
    'posts_per_page' => -1,
    'orderby'        => 'menu_order',
    'order'          => 'ASC',
] );

// Re-order by saved order.
if ( ! empty( $lesson_order ) && ! empty( $lessons ) ) {
    $keyed = [];
    foreach ( $lessons as $l ) {
        $keyed[ $l->ID ] = $l;
    }
    $ordered = [];
    foreach ( $lesson_order as $lid ) {
        if ( isset( $keyed[ $lid ] ) ) {
            $ordered[] = $keyed[ $lid ];
            unset( $keyed[ $lid ] );
        }
    }
    $lessons = array_merge( $ordered, array_values( $keyed ) );
}
?>
<div class="fg-lms-course-builder">
    <p class="description">
        <?php esc_html_e( 'Drag to reorder. Assign lessons/quizzes to this course via their own edit screens.', 'fg-lms' ); ?>
    </p>

    <?php if ( empty( $lessons ) ) : ?>
        <p>
            <?php
            printf(
                wp_kses(
                    /* translators: %s: link to new lesson */
                    __( 'No lessons yet. <a href="%s">Create a lesson</a> and set this course as its parent.', 'fg-lms' ),
                    [ 'a' => [ 'href' => [] ] ]
                ),
                esc_url( admin_url( 'post-new.php?post_type=fg_lesson' ) )
            );
            ?>
        </p>
    <?php else : ?>
        <ul id="fg-lms-lesson-order" class="fg-lms-sortable">
            <?php foreach ( $lessons as $lesson ) : ?>
            <li class="fg-lms-sortable-item" data-id="<?php echo esc_attr( $lesson->ID ); ?>">
                <input type="hidden" name="fg_lms_lesson_order[]" value="<?php echo esc_attr( $lesson->ID ); ?>">
                <span class="dashicons dashicons-move fg-lms-drag-handle"></span>
                <span class="fg-lms-sortable-type"><?php echo esc_html( 'fg_quiz' === $lesson->post_type ? __( 'Quiz', 'fg-lms' ) : __( 'Lesson', 'fg-lms' ) ); ?></span>
                <span class="fg-lms-sortable-title"><?php echo esc_html( $lesson->post_title ); ?></span>
                <a href="<?php echo esc_url( get_edit_post_link( $lesson->ID ) ); ?>" class="fg-lms-sortable-edit"><?php esc_html_e( 'Edit', 'fg-lms' ); ?></a>
                <span class="fg-lms-sortable-status fg-lms-badge fg-lms-badge--<?php echo esc_attr( $lesson->post_status ); ?>"><?php echo esc_html( ucfirst( $lesson->post_status ) ); ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <div style="margin-top:12px">
        <a href="<?php echo esc_url( add_query_arg( [ 'post_type' => 'fg_lesson', '_fg_lms_course_id' => $post->ID ], admin_url( 'post-new.php' ) ) ); ?>" class="button">
            <?php esc_html_e( '+ Add Lesson', 'fg-lms' ); ?>
        </a>
        &nbsp;
        <a href="<?php echo esc_url( add_query_arg( [ 'post_type' => 'fg_quiz', '_fg_lms_course_id' => $post->ID ], admin_url( 'post-new.php' ) ) ); ?>" class="button">
            <?php esc_html_e( '+ Add Quiz', 'fg-lms' ); ?>
        </a>
    </div>
</div>
