<?php
/**
 * Admin dashboard view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

global $wpdb;

$total_courses     = wp_count_posts( 'fg_course' )->publish ?? 0;
$total_lessons     = ( wp_count_posts( 'fg_lesson' )->publish ?? 0 ) + ( wp_count_posts( 'fg_quiz' )->publish ?? 0 );
$total_enrollments = fg_lms()->enrollment->total_enrollments();
$total_students    = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}fg_lms_enrollments" );
$total_completed   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}fg_lms_enrollments WHERE status = 'completed'" );
$total_certs       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}fg_lms_certificates" );

$brand_name = esc_html( get_option( 'fg_lms_brand_name', 'Flagstaff Group LMS' ) );

// Recent enrollments.
$recent_enrollments = $wpdb->get_results(
    "SELECT e.*, u.display_name, u.user_email, p.post_title AS course_title
       FROM {$wpdb->prefix}fg_lms_enrollments e
       JOIN {$wpdb->users} u ON u.ID = e.user_id
       JOIN {$wpdb->posts} p ON p.ID = e.course_id
      ORDER BY e.enrolled_at DESC
      LIMIT 10"
);
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1 class="fg-lms-admin-title"><?php echo $brand_name; ?> &mdash; <?php esc_html_e( 'Dashboard', 'fg-lms' ); ?></h1>
    </div>

    <!-- Stats row -->
    <div class="fg-lms-stats-grid">
        <div class="fg-lms-stat-card">
            <span class="dashicons dashicons-welcome-learn-more"></span>
            <div>
                <h3><?php echo esc_html( number_format_i18n( $total_courses ) ); ?></h3>
                <p><?php esc_html_e( 'Published Courses', 'fg-lms' ); ?></p>
            </div>
        </div>
        <div class="fg-lms-stat-card">
            <span class="dashicons dashicons-book-alt"></span>
            <div>
                <h3><?php echo esc_html( number_format_i18n( $total_lessons ) ); ?></h3>
                <p><?php esc_html_e( 'Lessons & Quizzes', 'fg-lms' ); ?></p>
            </div>
        </div>
        <div class="fg-lms-stat-card">
            <span class="dashicons dashicons-groups"></span>
            <div>
                <h3><?php echo esc_html( number_format_i18n( $total_students ) ); ?></h3>
                <p><?php esc_html_e( 'Active Students', 'fg-lms' ); ?></p>
            </div>
        </div>
        <div class="fg-lms-stat-card">
            <span class="dashicons dashicons-yes-alt"></span>
            <div>
                <h3><?php echo esc_html( number_format_i18n( $total_completed ) ); ?></h3>
                <p><?php esc_html_e( 'Completions', 'fg-lms' ); ?></p>
            </div>
        </div>
        <div class="fg-lms-stat-card">
            <span class="dashicons dashicons-awards"></span>
            <div>
                <h3><?php echo esc_html( number_format_i18n( $total_certs ) ); ?></h3>
                <p><?php esc_html_e( 'Certificates Issued', 'fg-lms' ); ?></p>
            </div>
        </div>
    </div>

    <!-- Quick links -->
    <div class="fg-lms-quick-links">
        <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=fg_course' ) ); ?>" class="fg-lms-btn fg-lms-btn--primary">
            <span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'New Course', 'fg-lms' ); ?>
        </a>
        <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=fg_lesson' ) ); ?>" class="fg-lms-btn fg-lms-btn--outline">
            <span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'New Lesson', 'fg-lms' ); ?>
        </a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=fg-lms-memberships&action=new' ) ); ?>" class="fg-lms-btn fg-lms-btn--outline">
            <span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'New Plan', 'fg-lms' ); ?>
        </a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=fg-lms-settings' ) ); ?>" class="fg-lms-btn fg-lms-btn--ghost">
            <span class="dashicons dashicons-admin-settings"></span> <?php esc_html_e( 'Settings', 'fg-lms' ); ?>
        </a>
    </div>

    <!-- Recent Enrollments Table -->
    <div class="fg-lms-admin-card">
        <h2><?php esc_html_e( 'Recent Enrollments', 'fg-lms' ); ?></h2>
        <?php if ( $recent_enrollments ) : ?>
        <table class="widefat fg-lms-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Student', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Email', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Course', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Enrolled', 'fg-lms' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $recent_enrollments as $row ) : ?>
                <tr>
                    <td><?php echo esc_html( $row->display_name ); ?></td>
                    <td><?php echo esc_html( $row->user_email ); ?></td>
                    <td><?php echo esc_html( $row->course_title ); ?></td>
                    <td><span class="fg-lms-badge fg-lms-badge--<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                    <td><?php echo esc_html( wp_date( get_option( 'date_format' ), strtotime( $row->enrolled_at ) ) ); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p><?php esc_html_e( 'No enrollments yet.', 'fg-lms' ); ?></p>
        <?php endif; ?>
    </div>
</div>
