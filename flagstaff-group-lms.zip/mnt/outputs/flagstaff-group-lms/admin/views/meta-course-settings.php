<?php
/**
 * Course Settings meta box.
 *
 * @var WP_Post $post
 * @var bool    $is_free
 * @var int     $passing_score
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;
?>
<p>
    <label>
        <input type="checkbox" name="fg_lms_is_free" value="1" <?php checked( $is_free ); ?>>
        <?php esc_html_e( 'Free course (bypass membership check)', 'fg-lms' ); ?>
    </label>
</p>
<p>
    <label for="fg_lms_passing_score"><strong><?php esc_html_e( 'Quiz Passing Score (%)', 'fg-lms' ); ?></strong></label><br>
    <input type="number" id="fg_lms_passing_score" name="fg_lms_passing_score"
           value="<?php echo esc_attr( $passing_score ); ?>" min="0" max="100" style="width:80px">
</p>
