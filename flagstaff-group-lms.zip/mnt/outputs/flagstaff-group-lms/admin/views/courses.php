<?php
/**
 * Admin Courses list view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

$courses = get_posts( [
    'post_type'      => 'fg_course',
    'post_status'    => [ 'publish', 'draft' ],
    'posts_per_page' => -1,
    'orderby'        => 'date',
    'order'          => 'DESC',
] );
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1><?php esc_html_e( 'Courses', 'fg-lms' ); ?></h1>
        <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=fg_course' ) ); ?>" class="fg-lms-btn fg-lms-btn--primary">
            <?php esc_html_e( '+ New Course', 'fg-lms' ); ?>
        </a>
    </div>

    <div class="fg-lms-admin-card">
        <?php if ( $courses ) : ?>
        <table class="widefat fg-lms-table">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Course Title', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Category', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Lessons', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Students', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'fg-lms' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $courses as $course ) :
                    $lesson_ids  = fg_lms()->progress->get_course_lesson_ids( $course->ID );
                    $enrollments = fg_lms()->enrollment->get_course_enrollments( $course->ID );
                    $cats        = get_the_terms( $course->ID, 'fg_course_cat' );
                    $cat_names   = $cats && ! is_wp_error( $cats )
                                    ? implode( ', ', wp_list_pluck( $cats, 'name' ) ) : '—';
                ?>
                <tr>
                    <td><strong><a href="<?php echo esc_url( get_edit_post_link( $course->ID ) ); ?>"><?php echo esc_html( $course->post_title ); ?></a></strong></td>
                    <td><?php echo esc_html( $cat_names ); ?></td>
                    <td><?php echo esc_html( count( $lesson_ids ) ); ?></td>
                    <td><?php echo esc_html( count( $enrollments ) ); ?></td>
                    <td><span class="fg-lms-badge fg-lms-badge--<?php echo esc_attr( $course->post_status ); ?>"><?php echo esc_html( ucfirst( $course->post_status ) ); ?></span></td>
                    <td class="fg-lms-table-actions">
                        <a href="<?php echo esc_url( get_edit_post_link( $course->ID ) ); ?>"><?php esc_html_e( 'Edit', 'fg-lms' ); ?></a>
                        &nbsp;|&nbsp;
                        <a href="<?php echo esc_url( get_permalink( $course->ID ) ); ?>" target="_blank"><?php esc_html_e( 'View', 'fg-lms' ); ?></a>
                        &nbsp;|&nbsp;
                        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'fg-lms-reports', 'course_id' => $course->ID ], admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Report', 'fg-lms' ); ?></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p><?php esc_html_e( 'No courses yet. Create your first course!', 'fg-lms' ); ?></p>
        <?php endif; ?>
    </div>
</div>
