<?php
/**
 * Lesson Settings meta box.
 *
 * @var WP_Post $post
 * @var int     $course_id
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

$courses = get_posts( [
    'post_type'      => 'fg_course',
    'post_status'    => [ 'publish', 'draft' ],
    'posts_per_page' => -1,
    'orderby'        => 'title',
    'order'          => 'ASC',
] );
?>
<p>
    <label for="fg_lms_course_id"><strong><?php esc_html_e( 'Parent Course', 'fg-lms' ); ?></strong></label><br>
    <select id="fg_lms_course_id" name="fg_lms_course_id" style="width:100%">
        <option value="0"><?php esc_html_e( '— None —', 'fg-lms' ); ?></option>
        <?php foreach ( $courses as $c ) : ?>
        <option value="<?php echo esc_attr( $c->ID ); ?>" <?php selected( $course_id, $c->ID ); ?>><?php echo esc_html( $c->post_title ); ?></option>
        <?php endforeach; ?>
    </select>
    <span class="description"><?php esc_html_e( 'Assigns this lesson to the selected course.', 'fg-lms' ); ?></span>
</p>
