<?php
/**
 * Admin Students management view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$selected_uid = absint( $_GET['uid'] ?? 0 );
$notice       = '';

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! empty( $_GET['enrolled'] ) ) {
    $notice = '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Student enrolled successfully.', 'fg-lms' ) . '</p></div>';
}
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! empty( $_GET['unenrolled'] ) ) {
    $notice = '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Student unenrolled.', 'fg-lms' ) . '</p></div>';
}

// All WP users.
$all_users = get_users( [ 'orderby' => 'display_name', 'order' => 'ASC', 'number' => 200 ] );

// Courses for enroll form.
$all_courses = get_posts( [ 'post_type' => 'fg_course', 'post_status' => 'publish', 'posts_per_page' => -1 ] );

// Selected student data.
$student_enrollments = $selected_uid ? fg_lms()->enrollment->get_user_enrollments( $selected_uid ) : [];
$active_membership   = $selected_uid ? fg_lms()->membership->get_user_active_membership( $selected_uid ) : null;
$selected_user       = $selected_uid ? get_userdata( $selected_uid ) : null;
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1><?php esc_html_e( 'Students', 'fg-lms' ); ?></h1>
    </div>

    <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

    <div class="fg-lms-two-col">
        <!-- Student list -->
        <div class="fg-lms-admin-card fg-lms-student-list">
            <h2><?php esc_html_e( 'All Students', 'fg-lms' ); ?></h2>
            <table class="widefat fg-lms-table">
                <thead><tr>
                    <th><?php esc_html_e( 'Name', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Email', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Membership', 'fg-lms' ); ?></th>
                </tr></thead>
                <tbody>
                    <?php foreach ( $all_users as $u ) :
                        $m = fg_lms()->membership->get_user_active_membership( $u->ID );
                    ?>
                    <tr>
                        <td>
                            <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'fg-lms-students', 'uid' => $u->ID ], admin_url( 'admin.php' ) ) ); ?>">
                                <?php echo esc_html( $u->display_name ); ?>
                            </a>
                        </td>
                        <td><?php echo esc_html( $u->user_email ); ?></td>
                        <td><?php echo $m ? '<span class="fg-lms-badge fg-lms-badge--active">' . esc_html( $m->plan_name ) . '</span>' : '<span class="fg-lms-badge fg-lms-badge--inactive">' . esc_html__( 'None', 'fg-lms' ) . '</span>'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Student detail panel -->
        <?php if ( $selected_user ) : ?>
        <div class="fg-lms-admin-card fg-lms-student-detail">
            <h2><?php echo esc_html( $selected_user->display_name ); ?></h2>
            <p class="description"><?php echo esc_html( $selected_user->user_email ); ?></p>

            <?php if ( $active_membership ) : ?>
            <p><strong><?php esc_html_e( 'Active Plan:', 'fg-lms' ); ?></strong>
               <?php echo esc_html( $active_membership->plan_name ); ?>
               &mdash; <?php echo $active_membership->expires_at
                            ? esc_html( sprintf( __( 'Expires %s', 'fg-lms' ), wp_date( get_option( 'date_format' ), strtotime( $active_membership->expires_at ) ) ) )
                            : esc_html__( 'Lifetime', 'fg-lms' ); ?>
            </p>
            <?php endif; ?>

            <h3><?php esc_html_e( 'Enrollments', 'fg-lms' ); ?></h3>
            <?php if ( $student_enrollments ) : ?>
            <table class="widefat fg-lms-table">
                <thead><tr>
                    <th><?php esc_html_e( 'Course', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Progress', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Status', 'fg-lms' ); ?></th>
                    <th><?php esc_html_e( 'Action', 'fg-lms' ); ?></th>
                </tr></thead>
                <tbody>
                    <?php foreach ( $student_enrollments as $enr ) :
                        $pct = fg_lms()->progress->get_course_progress( $selected_uid, (int) $enr->course_id );
                    ?>
                    <tr>
                        <td><?php echo esc_html( $enr->course_title ); ?></td>
                        <td>
                            <div class="fg-lms-mini-progress">
                                <div class="fg-lms-mini-bar" style="width:<?php echo esc_attr( $pct ); ?>%"></div>
                            </div>
                            <small><?php echo esc_html( $pct ); ?>%</small>
                        </td>
                        <td><span class="fg-lms-badge fg-lms-badge--<?php echo esc_attr( $enr->status ); ?>"><?php echo esc_html( ucfirst( $enr->status ) ); ?></span></td>
                        <td>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action"    value="fg_lms_unenroll_user">
                                <input type="hidden" name="user_id"   value="<?php echo esc_attr( $selected_uid ); ?>">
                                <input type="hidden" name="course_id" value="<?php echo esc_attr( $enr->course_id ); ?>">
                                <?php wp_nonce_field( 'fg_lms_unenroll_user' ); ?>
                                <button type="submit" class="button button-small"
                                        onclick="return confirm('<?php esc_attr_e( 'Remove this enrollment?', 'fg-lms' ); ?>');">
                                    <?php esc_html_e( 'Unenroll', 'fg-lms' ); ?>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else : ?>
                <p><?php esc_html_e( 'No enrollments.', 'fg-lms' ); ?></p>
            <?php endif; ?>

            <h3><?php esc_html_e( 'Manually Enroll', 'fg-lms' ); ?></h3>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action"  value="fg_lms_enroll_user">
                <input type="hidden" name="user_id" value="<?php echo esc_attr( $selected_uid ); ?>">
                <?php wp_nonce_field( 'fg_lms_enroll_user' ); ?>
                <select name="course_id" required>
                    <option value=""><?php esc_html_e( '— Select a course —', 'fg-lms' ); ?></option>
                    <?php foreach ( $all_courses as $c ) : ?>
                    <option value="<?php echo esc_attr( $c->ID ); ?>"><?php echo esc_html( $c->post_title ); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="button button-primary"><?php esc_html_e( 'Enroll', 'fg-lms' ); ?></button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
