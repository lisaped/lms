<?php
/**
 * Admin Reports view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$course_id = absint( $_GET['course_id'] ?? 0 );
$courses   = get_posts( [ 'post_type' => 'fg_course', 'post_status' => 'publish', 'posts_per_page' => -1 ] );

$overview = $course_id ? fg_lms()->progress->get_course_progress_overview( $course_id ) : [];
$selected_course = $course_id ? get_post( $course_id ) : null;
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1><?php esc_html_e( 'Reports', 'fg-lms' ); ?></h1>
    </div>

    <div class="fg-lms-admin-card">
        <form method="get">
            <input type="hidden" name="page" value="fg-lms-reports">
            <label for="fg-lms-report-course"><strong><?php esc_html_e( 'Select Course:', 'fg-lms' ); ?></strong></label>
            <select id="fg-lms-report-course" name="course_id" onchange="this.form.submit()">
                <option value=""><?php esc_html_e( '— All Courses —', 'fg-lms' ); ?></option>
                <?php foreach ( $courses as $c ) : ?>
                <option value="<?php echo esc_attr( $c->ID ); ?>" <?php selected( $course_id, $c->ID ); ?>><?php echo esc_html( $c->post_title ); ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <?php if ( $course_id && $selected_course ) : ?>
    <div class="fg-lms-admin-card">
        <h2><?php echo esc_html( $selected_course->post_title ); ?> &mdash; <?php esc_html_e( 'Student Progress', 'fg-lms' ); ?></h2>

        <?php $total_lessons = fg_lms()->progress->get_lesson_count( $course_id ); ?>

        <?php if ( $overview ) : ?>
        <table class="widefat fg-lms-table">
            <thead><tr>
                <th><?php esc_html_e( 'Student', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Email', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Progress', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Lessons Done', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Last Active', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Certificate', 'fg-lms' ); ?></th>
            </tr></thead>
            <tbody>
                <?php foreach ( $overview as $row ) :
                    $pct  = $total_lessons > 0 ? (int) min( 100, round( $row->completed_lessons / $total_lessons * 100 ) ) : 0;
                    $cert = fg_lms()->certificate->get_certificate( (int) $row->user_id, $course_id );
                ?>
                <tr>
                    <td><?php echo esc_html( $row->display_name ); ?></td>
                    <td><?php echo esc_html( $row->user_email ); ?></td>
                    <td>
                        <div class="fg-lms-mini-progress">
                            <div class="fg-lms-mini-bar" style="width:<?php echo esc_attr( $pct ); ?>%"></div>
                        </div>
                        <small><?php echo esc_html( $pct ); ?>%</small>
                    </td>
                    <td><?php echo esc_html( $row->completed_lessons . ' / ' . $total_lessons ); ?></td>
                    <td><?php echo $row->last_activity
                            ? esc_html( wp_date( get_option( 'date_format' ), strtotime( $row->last_activity ) ) )
                            : '—'; ?>
                    </td>
                    <td>
                        <?php if ( $cert ) : ?>
                            <a href="<?php echo esc_url( fg_lms()->certificate->get_download_url( $cert->certificate_number ) ); ?>" target="_blank">
                                <?php esc_html_e( 'View', 'fg-lms' ); ?>
                            </a>
                        <?php else : ?>
                            &mdash;
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p><?php esc_html_e( 'No students enrolled in this course yet.', 'fg-lms' ); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
