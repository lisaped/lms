<?php
/**
 * Admin Membership Plans view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$action  = sanitize_text_field( $_GET['action'] ?? 'list' );
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$plan_id = absint( $_GET['plan_id'] ?? 0 );

$notice = '';
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! empty( $_GET['saved'] ) ) {
    $notice = '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Plan saved.', 'fg-lms' ) . '</p></div>';
}
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! empty( $_GET['deleted'] ) ) {
    $notice = '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Plan deleted.', 'fg-lms' ) . '</p></div>';
}

$all_plans  = fg_lms()->membership->get_plans( 'active' ) + fg_lms()->membership->get_plans( 'inactive' );
$all_plans  = fg_lms()->membership->get_plans( '' ) ?: [];
$edit_plan  = ( $plan_id && in_array( $action, [ 'edit' ], true ) ) ? fg_lms()->membership->get_plan( $plan_id ) : null;
$all_courses = get_posts( [ 'post_type' => 'fg_course', 'post_status' => 'publish', 'posts_per_page' => -1 ] );
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1><?php esc_html_e( 'Membership Plans', 'fg-lms' ); ?></h1>
        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'fg-lms-memberships', 'action' => 'new' ], admin_url( 'admin.php' ) ) ); ?>" class="fg-lms-btn fg-lms-btn--primary">
            <?php esc_html_e( '+ New Plan', 'fg-lms' ); ?>
        </a>
    </div>

    <?php echo $notice; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

    <?php if ( in_array( $action, [ 'new', 'edit' ], true ) ) : ?>

    <!-- Plan form -->
    <div class="fg-lms-admin-card">
        <h2><?php echo $edit_plan ? esc_html__( 'Edit Plan', 'fg-lms' ) : esc_html__( 'Create New Plan', 'fg-lms' ); ?></h2>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action"  value="fg_lms_save_plan">
            <input type="hidden" name="plan_id" value="<?php echo esc_attr( $plan_id ); ?>">
            <?php wp_nonce_field( 'fg_lms_save_plan' ); ?>

            <table class="form-table">
                <tr>
                    <th><label for="plan_name"><?php esc_html_e( 'Plan Name', 'fg-lms' ); ?></label></th>
                    <td><input type="text" id="plan_name" name="plan_name" value="<?php echo esc_attr( $edit_plan->name ?? '' ); ?>" class="regular-text" required></td>
                </tr>
                <tr>
                    <th><label for="plan_description"><?php esc_html_e( 'Description', 'fg-lms' ); ?></label></th>
                    <td><textarea id="plan_description" name="plan_description" rows="3" class="large-text"><?php echo esc_textarea( $edit_plan->description ?? '' ); ?></textarea></td>
                </tr>
                <tr>
                    <th><label for="plan_price"><?php esc_html_e( 'Price (USD)', 'fg-lms' ); ?></label></th>
                    <td><input type="number" id="plan_price" name="plan_price" value="<?php echo esc_attr( $edit_plan->price ?? '0' ); ?>" step="0.01" min="0" class="small-text"></td>
                </tr>
                <tr>
                    <th><label for="plan_duration_days"><?php esc_html_e( 'Duration (days)', 'fg-lms' ); ?></label></th>
                    <td>
                        <input type="number" id="plan_duration_days" name="plan_duration_days" value="<?php echo esc_attr( $edit_plan->duration_days ?? '0' ); ?>" min="0" class="small-text">
                        <p class="description"><?php esc_html_e( '0 = Lifetime access', 'fg-lms' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="plan_course_access"><?php esc_html_e( 'Course Access', 'fg-lms' ); ?></label></th>
                    <td>
                        <select id="plan_course_access" name="plan_course_access" onchange="document.getElementById('fg-lms-specific-courses').style.display=this.value==='specific'?'block':'none'">
                            <option value="all"      <?php selected( $edit_plan->course_access ?? 'all', 'all' ); ?>><?php esc_html_e( 'All Courses', 'fg-lms' ); ?></option>
                            <option value="specific" <?php selected( $edit_plan->course_access ?? '', 'specific' ); ?>><?php esc_html_e( 'Specific Courses', 'fg-lms' ); ?></option>
                        </select>
                        <div id="fg-lms-specific-courses" style="display:<?php echo isset( $edit_plan->course_access ) && 'specific' === $edit_plan->course_access ? 'block' : 'none'; ?>;margin-top:8px">
                            <?php
                            $selected_course_ids = $edit_plan ? fg_lms()->membership->get_plan_course_ids( (int) $edit_plan->id ) : [];
                            foreach ( $all_courses as $c ) :
                            ?>
                            <label style="display:block">
                                <input type="checkbox" name="plan_courses[]" value="<?php echo esc_attr( $c->ID ); ?>"
                                       <?php checked( in_array( $c->ID, $selected_course_ids, true ) ); ?>>
                                <?php echo esc_html( $c->post_title ); ?>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th><label for="plan_status"><?php esc_html_e( 'Status', 'fg-lms' ); ?></label></th>
                    <td>
                        <select id="plan_status" name="plan_status">
                            <option value="active"   <?php selected( $edit_plan->status ?? 'active', 'active' ); ?>><?php esc_html_e( 'Active', 'fg-lms' ); ?></option>
                            <option value="inactive" <?php selected( $edit_plan->status ?? '', 'inactive' ); ?>><?php esc_html_e( 'Inactive', 'fg-lms' ); ?></option>
                        </select>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" class="button button-primary"><?php esc_html_e( 'Save Plan', 'fg-lms' ); ?></button>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=fg-lms-memberships' ) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'fg-lms' ); ?></a>
            </p>
        </form>
    </div>

    <?php else : ?>

    <!-- Plans list -->
    <div class="fg-lms-admin-card">
        <?php if ( $all_plans ) : ?>
        <table class="widefat fg-lms-table">
            <thead><tr>
                <th><?php esc_html_e( 'Plan Name', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Price', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Duration', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Access', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Status', 'fg-lms' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'fg-lms' ); ?></th>
            </tr></thead>
            <tbody>
                <?php foreach ( $all_plans as $plan ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $plan->name ); ?></strong></td>
                    <td><?php echo esc_html( '$' . number_format( (float) $plan->price, 2 ) ); ?></td>
                    <td><?php echo $plan->duration_days > 0 ? esc_html( sprintf( _n( '%d day', '%d days', $plan->duration_days, 'fg-lms' ), $plan->duration_days ) ) : esc_html__( 'Lifetime', 'fg-lms' ); ?></td>
                    <td><?php echo 'all' === $plan->course_access ? esc_html__( 'All Courses', 'fg-lms' ) : esc_html__( 'Specific', 'fg-lms' ); ?></td>
                    <td><span class="fg-lms-badge fg-lms-badge--<?php echo esc_attr( $plan->status ); ?>"><?php echo esc_html( ucfirst( $plan->status ) ); ?></span></td>
                    <td class="fg-lms-table-actions">
                        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'fg-lms-memberships', 'action' => 'edit', 'plan_id' => $plan->id ], admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'Edit', 'fg-lms' ); ?></a>
                        &nbsp;|&nbsp;
                        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
                            <input type="hidden" name="action"  value="fg_lms_delete_plan">
                            <input type="hidden" name="plan_id" value="<?php echo esc_attr( $plan->id ); ?>">
                            <?php wp_nonce_field( 'fg_lms_delete_plan' ); ?>
                            <button type="submit" class="button-link fg-lms-link-danger"
                                    onclick="return confirm('<?php esc_attr_e( 'Delete this plan?', 'fg-lms' ); ?>');">
                                <?php esc_html_e( 'Delete', 'fg-lms' ); ?>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
            <p><?php esc_html_e( 'No plans yet. Create a membership plan to get started.', 'fg-lms' ); ?></p>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
