<?php
/**
 * Admin Settings view.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="wrap fg-lms-admin-wrap">
    <div class="fg-lms-admin-header">
        <h1><?php esc_html_e( 'LMS Settings', 'fg-lms' ); ?></h1>
    </div>

    <div class="fg-lms-admin-card">
        <form method="post" action="options.php">
            <?php settings_fields( 'fg_lms_settings' ); ?>

            <h2 class="title"><?php esc_html_e( 'Branding', 'fg-lms' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><label for="fg_lms_brand_name"><?php esc_html_e( 'Brand / Platform Name', 'fg-lms' ); ?></label></th>
                    <td><input type="text" id="fg_lms_brand_name" name="fg_lms_brand_name"
                               value="<?php echo esc_attr( get_option( 'fg_lms_brand_name' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="fg_lms_primary_color"><?php esc_html_e( 'Primary Color', 'fg-lms' ); ?></label></th>
                    <td>
                        <input type="color" id="fg_lms_primary_color" name="fg_lms_primary_color"
                               value="<?php echo esc_attr( get_option( 'fg_lms_primary_color', '#C8102E' ) ); ?>">
                        <p class="description"><?php esc_html_e( 'Used for buttons, headings, and accents.', 'fg-lms' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="fg_lms_secondary_color"><?php esc_html_e( 'Secondary Color', 'fg-lms' ); ?></label></th>
                    <td><input type="color" id="fg_lms_secondary_color" name="fg_lms_secondary_color"
                               value="<?php echo esc_attr( get_option( 'fg_lms_secondary_color', '#1A1A1A' ) ); ?>"></td>
                </tr>
            </table>

            <h2 class="title"><?php esc_html_e( 'Pages', 'fg-lms' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Create pages with the appropriate shortcode and select them here.', 'fg-lms' ); ?></p>
            <table class="form-table">
                <tr>
                    <th><label for="fg_lms_catalog_page_id"><?php esc_html_e( 'Course Catalog Page', 'fg-lms' ); ?></label></th>
                    <td>
                        <?php wp_dropdown_pages( [
                            'name'             => 'fg_lms_catalog_page_id',
                            'id'               => 'fg_lms_catalog_page_id',
                            'selected'         => get_option( 'fg_lms_catalog_page_id', 0 ),
                            'show_option_none' => __( '— Select —', 'fg-lms' ),
                        ] ); ?>
                        <p class="description"><?php echo wp_kses_post( __( 'Add shortcode: <code>[fg_lms_catalog]</code>', 'fg-lms' ) ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="fg_lms_dashboard_page_id"><?php esc_html_e( 'Student Dashboard Page', 'fg-lms' ); ?></label></th>
                    <td>
                        <?php wp_dropdown_pages( [
                            'name'             => 'fg_lms_dashboard_page_id',
                            'id'               => 'fg_lms_dashboard_page_id',
                            'selected'         => get_option( 'fg_lms_dashboard_page_id', 0 ),
                            'show_option_none' => __( '— Select —', 'fg-lms' ),
                        ] ); ?>
                        <p class="description"><?php echo wp_kses_post( __( 'Add shortcode: <code>[fg_lms_dashboard]</code>', 'fg-lms' ) ); ?></p>
                    </td>
                </tr>
            </table>

            <h2 class="title"><?php esc_html_e( 'Certificates', 'fg-lms' ); ?></h2>
            <table class="form-table">
                <tr>
                    <th><label for="fg_lms_certificate_logo_url"><?php esc_html_e( 'Logo URL', 'fg-lms' ); ?></label></th>
                    <td>
                        <input type="url" id="fg_lms_certificate_logo_url" name="fg_lms_certificate_logo_url"
                               value="<?php echo esc_attr( get_option( 'fg_lms_certificate_logo_url' ) ); ?>" class="regular-text">
                        <p class="description"><?php esc_html_e( 'Displayed at the top of the certificate.', 'fg-lms' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="fg_lms_cert_signatory_name"><?php esc_html_e( 'Signatory Name', 'fg-lms' ); ?></label></th>
                    <td><input type="text" id="fg_lms_cert_signatory_name" name="fg_lms_cert_signatory_name"
                               value="<?php echo esc_attr( get_option( 'fg_lms_cert_signatory_name' ) ); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th><label for="fg_lms_cert_signatory_title"><?php esc_html_e( 'Signatory Title', 'fg-lms' ); ?></label></th>
                    <td><input type="text" id="fg_lms_cert_signatory_title" name="fg_lms_cert_signatory_title"
                               value="<?php echo esc_attr( get_option( 'fg_lms_cert_signatory_title' ) ); ?>" class="regular-text"></td>
                </tr>
            </table>

            <?php submit_button( __( 'Save Settings', 'fg-lms' ) ); ?>
        </form>
    </div>
</div>
