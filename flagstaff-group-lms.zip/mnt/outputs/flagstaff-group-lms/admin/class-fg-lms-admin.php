<?php
/**
 * Admin: registers menus, enqueues assets, and delegates to sub-pages.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Admin {

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'register_menus' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_post_fg_lms_save_plan',    [ $this, 'handle_save_plan' ] );
        add_action( 'admin_post_fg_lms_delete_plan',  [ $this, 'handle_delete_plan' ] );
        add_action( 'admin_post_fg_lms_enroll_user',  [ $this, 'handle_enroll_user' ] );
        add_action( 'admin_post_fg_lms_unenroll_user',[ $this, 'handle_unenroll_user' ] );
        add_action( 'save_post_fg_course',   [ $this, 'save_course_meta' ], 10, 2 );
        add_action( 'save_post_fg_lesson',   [ $this, 'save_lesson_meta' ], 10, 2 );
        add_action( 'add_meta_boxes',        [ $this, 'add_meta_boxes' ] );

        // Add CPT to LMS admin menu rather than default WP menu.
        add_filter( 'post_type_link', [ $this, 'filter_cpt_links' ], 10, 2 );
    }

    // ── Admin menu ────────────────────────────────────────────────────────────

    public function register_menus(): void {
        $primary = get_option( 'fg_lms_primary_color', '#C8102E' );

        add_menu_page(
            __( 'Flagstaff LMS', 'fg-lms' ),
            __( 'Flagstaff LMS', 'fg-lms' ),
            'manage_options',
            'fg-lms',
            [ $this, 'page_dashboard' ],
            'dashicons-welcome-learn-more',
            26
        );

        add_submenu_page( 'fg-lms', __( 'Dashboard', 'fg-lms' ),    __( 'Dashboard', 'fg-lms' ),    'manage_options', 'fg-lms',               [ $this, 'page_dashboard' ] );
        add_submenu_page( 'fg-lms', __( 'Courses', 'fg-lms' ),      __( 'Courses', 'fg-lms' ),      'manage_options', 'fg-lms-courses',        [ $this, 'page_courses' ] );
        add_submenu_page( 'fg-lms', __( 'Students', 'fg-lms' ),     __( 'Students', 'fg-lms' ),     'manage_options', 'fg-lms-students',       [ $this, 'page_students' ] );
        add_submenu_page( 'fg-lms', __( 'Memberships', 'fg-lms' ),  __( 'Memberships', 'fg-lms' ),  'manage_options', 'fg-lms-memberships',    [ $this, 'page_memberships' ] );
        add_submenu_page( 'fg-lms', __( 'Reports', 'fg-lms' ),      __( 'Reports', 'fg-lms' ),      'manage_options', 'fg-lms-reports',        [ $this, 'page_reports' ] );
        add_submenu_page( 'fg-lms', __( 'Settings', 'fg-lms' ),     __( 'Settings', 'fg-lms' ),     'manage_options', 'fg-lms-settings',       [ $this, 'page_settings' ] );
    }

    // ── Asset enqueueing ──────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        // Only load on our pages and CPT edit screens.
        $our_pages = [ 'toplevel_page_fg-lms', 'flagstaff-lms_page_fg-lms-courses',
                       'flagstaff-lms_page_fg-lms-students', 'flagstaff-lms_page_fg-lms-memberships',
                       'flagstaff-lms_page_fg-lms-reports', 'flagstaff-lms_page_fg-lms-settings' ];

        $is_cpt = in_array( get_current_screen()->post_type ?? '', [ 'fg_course', 'fg_lesson', 'fg_quiz', 'fg_question' ], true );

        if ( ! in_array( $hook, $our_pages, true ) && ! $is_cpt ) {
            return;
        }

        wp_enqueue_style(
            'fg-lms-admin',
            FG_LMS_URL . 'assets/css/admin.css',
            [],
            FG_LMS_VERSION
        );

        wp_enqueue_script(
            'fg-lms-admin',
            FG_LMS_URL . 'assets/js/admin.js',
            [ 'jquery', 'jquery-ui-sortable' ],
            FG_LMS_VERSION,
            true
        );

        wp_localize_script( 'fg-lms-admin', 'FG_LMS', [
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'fg_lms_admin' ),
            'primary'     => get_option( 'fg_lms_primary_color', '#C8102E' ),
        ] );
    }

    // ── Settings API ──────────────────────────────────────────────────────────

    public function register_settings(): void {
        $fields = [
            'fg_lms_brand_name'           => 'sanitize_text_field',
            'fg_lms_primary_color'        => 'sanitize_hex_color',
            'fg_lms_secondary_color'      => 'sanitize_hex_color',
            'fg_lms_catalog_page_id'      => 'absint',
            'fg_lms_dashboard_page_id'    => 'absint',
            'fg_lms_certificate_logo_url' => 'esc_url_raw',
            'fg_lms_cert_signatory_name'  => 'sanitize_text_field',
            'fg_lms_cert_signatory_title' => 'sanitize_text_field',
            'fg_lms_redirect_after_login' => 'esc_url_raw',
        ];

        foreach ( $fields as $key => $sanitize_cb ) {
            register_setting( 'fg_lms_settings', $key, [
                'sanitize_callback' => $sanitize_cb,
            ] );
        }
    }

    // ── Page renderers ────────────────────────────────────────────────────────

    public function page_dashboard(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/dashboard.php';
    }

    public function page_courses(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/courses.php';
    }

    public function page_students(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/students.php';
    }

    public function page_memberships(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/memberships.php';
    }

    public function page_reports(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/reports.php';
    }

    public function page_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }
        include FG_LMS_DIR . 'admin/views/settings.php';
    }

    // ── Meta boxes ────────────────────────────────────────────────────────────

    public function add_meta_boxes(): void {
        add_meta_box(
            'fg_lms_course_builder',
            __( 'Course Builder', 'fg-lms' ),
            [ $this, 'render_course_builder' ],
            'fg_course',
            'normal',
            'high'
        );

        add_meta_box(
            'fg_lms_course_settings',
            __( 'Course Settings', 'fg-lms' ),
            [ $this, 'render_course_settings' ],
            'fg_course',
            'side'
        );

        add_meta_box(
            'fg_lms_lesson_settings',
            __( 'Lesson Settings', 'fg-lms' ),
            [ $this, 'render_lesson_settings' ],
            'fg_lesson',
            'side'
        );
    }

    public function render_course_builder( WP_Post $post ): void {
        wp_nonce_field( 'fg_lms_course_builder_' . $post->ID, 'fg_lms_course_builder_nonce' );
        $lesson_order = get_post_meta( $post->ID, '_fg_lms_lesson_order', true ) ?: [];
        include FG_LMS_DIR . 'admin/views/meta-course-builder.php';
    }

    public function render_course_settings( WP_Post $post ): void {
        wp_nonce_field( 'fg_lms_course_settings_' . $post->ID, 'fg_lms_course_settings_nonce' );
        $is_free        = (bool) get_post_meta( $post->ID, '_fg_lms_is_free', true );
        $passing_score  = (int) get_post_meta( $post->ID, '_fg_lms_passing_score', true ) ?: 80;
        include FG_LMS_DIR . 'admin/views/meta-course-settings.php';
    }

    public function render_lesson_settings( WP_Post $post ): void {
        wp_nonce_field( 'fg_lms_lesson_settings_' . $post->ID, 'fg_lms_lesson_settings_nonce' );
        $course_id = (int) get_post_meta( $post->ID, '_fg_lms_course_id', true );
        include FG_LMS_DIR . 'admin/views/meta-lesson-settings.php';
    }

    // ── Save meta ─────────────────────────────────────────────────────────────

    public function save_course_meta( int $post_id, WP_Post $post ): void {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        // Course builder nonce.
        if ( isset( $_POST['fg_lms_course_builder_nonce'] ) &&
             wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fg_lms_course_builder_nonce'] ) ),
                              'fg_lms_course_builder_' . $post_id ) ) {

            $lesson_order = isset( $_POST['fg_lms_lesson_order'] )
                ? array_map( 'absint', (array) wp_unslash( $_POST['fg_lms_lesson_order'] ) )
                : [];
            update_post_meta( $post_id, '_fg_lms_lesson_order', $lesson_order );
        }

        // Course settings nonce.
        if ( isset( $_POST['fg_lms_course_settings_nonce'] ) &&
             wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fg_lms_course_settings_nonce'] ) ),
                              'fg_lms_course_settings_' . $post_id ) ) {

            update_post_meta( $post_id, '_fg_lms_is_free',
                ! empty( $_POST['fg_lms_is_free'] ) ? 1 : 0 );
            update_post_meta( $post_id, '_fg_lms_passing_score',
                absint( $_POST['fg_lms_passing_score'] ?? 80 ) );
        }
    }

    public function save_lesson_meta( int $post_id, WP_Post $post ): void {
        if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        if ( isset( $_POST['fg_lms_lesson_settings_nonce'] ) &&
             wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fg_lms_lesson_settings_nonce'] ) ),
                              'fg_lms_lesson_settings_' . $post_id ) ) {

            $course_id = absint( $_POST['fg_lms_course_id'] ?? 0 );
            update_post_meta( $post_id, '_fg_lms_course_id', $course_id );
        }
    }

    // ── Admin POST handlers ────────────────────────────────────────────────────

    public function handle_save_plan(): void {
        check_admin_referer( 'fg_lms_save_plan' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }

        $id   = absint( $_POST['plan_id'] ?? 0 );
        $data = [
            'name'          => sanitize_text_field( wp_unslash( $_POST['plan_name'] ?? '' ) ),
            'description'   => wp_kses_post( wp_unslash( $_POST['plan_description'] ?? '' ) ),
            'price'         => (float) ( $_POST['plan_price'] ?? 0 ),
            'duration_days' => absint( $_POST['plan_duration_days'] ?? 0 ),
            'course_access' => sanitize_text_field( wp_unslash( $_POST['plan_course_access'] ?? 'all' ) ),
            'status'        => sanitize_text_field( wp_unslash( $_POST['plan_status'] ?? 'active' ) ),
        ];

        $plan_id = fg_lms()->membership->save_plan( $data, $id );

        if ( $plan_id && 'specific' === $data['course_access'] && ! empty( $_POST['plan_courses'] ) ) {
            $course_ids = array_map( 'absint', (array) wp_unslash( $_POST['plan_courses'] ) );
            fg_lms()->membership->set_plan_courses( $plan_id, $course_ids );
        }

        wp_redirect( add_query_arg( [ 'page' => 'fg-lms-memberships', 'saved' => 1 ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_delete_plan(): void {
        check_admin_referer( 'fg_lms_delete_plan' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }

        $id = absint( $_POST['plan_id'] ?? 0 );
        fg_lms()->membership->delete_plan( $id );

        wp_redirect( add_query_arg( [ 'page' => 'fg-lms-memberships', 'deleted' => 1 ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_enroll_user(): void {
        check_admin_referer( 'fg_lms_enroll_user' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }

        $user_id   = absint( $_POST['user_id']   ?? 0 );
        $course_id = absint( $_POST['course_id'] ?? 0 );

        fg_lms()->enrollment->enroll( $user_id, $course_id );

        wp_redirect( add_query_arg( [ 'page' => 'fg-lms-students', 'uid' => $user_id, 'enrolled' => 1 ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public function handle_unenroll_user(): void {
        check_admin_referer( 'fg_lms_unenroll_user' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Access denied.', 'fg-lms' ) );
        }

        $user_id   = absint( $_POST['user_id']   ?? 0 );
        $course_id = absint( $_POST['course_id'] ?? 0 );

        fg_lms()->enrollment->unenroll( $user_id, $course_id );

        wp_redirect( add_query_arg( [ 'page' => 'fg-lms-students', 'uid' => $user_id, 'unenrolled' => 1 ], admin_url( 'admin.php' ) ) );
        exit;
    }

    /** Ensure CPT edit links use the default WP edit screen. */
    public function filter_cpt_links( string $link, WP_Post $post ): string {
        return $link; // pass-through; customise if needed.
    }
}
