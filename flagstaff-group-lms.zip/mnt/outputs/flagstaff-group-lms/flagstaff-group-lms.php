<?php
/**
 * Plugin Name:       Flagstaff Group LMS
 * Plugin URI:        https://flagstaffgroup.com/lms
 * Description:       A full-featured Learning Management System branded for Flagstaff Group. Supports courses, lessons, quizzes, student progress tracking, memberships, and certificates.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            Flagstaff Group
 * Author URI:        https://flagstaffgroup.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       fg-lms
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

// ── Constants ────────────────────────────────────────────────────────────────
define( 'FG_LMS_VERSION',   '1.0.0' );
define( 'FG_LMS_FILE',      __FILE__ );
define( 'FG_LMS_DIR',       plugin_dir_path( __FILE__ ) );
define( 'FG_LMS_URL',       plugin_dir_url( __FILE__ ) );
define( 'FG_LMS_BASENAME',  plugin_basename( __FILE__ ) );
define( 'FG_LMS_DB_VERSION', '1.0.0' );

// ── Autoloader ───────────────────────────────────────────────────────────────
spl_autoload_register( function ( string $class ): void {
    $prefix = 'FG_LMS_';
    if ( strpos( $class, $prefix ) !== 0 ) {
        return;
    }
    $relative = strtolower( str_replace( [ $prefix, '_' ], [ '', '-' ], $class ) );
    $paths = [
        FG_LMS_DIR . 'includes/class-fg-lms-' . $relative . '.php',
        FG_LMS_DIR . 'admin/class-fg-lms-' . $relative . '.php',
        FG_LMS_DIR . 'public/class-fg-lms-' . $relative . '.php',
    ];
    foreach ( $paths as $path ) {
        if ( file_exists( $path ) ) {
            require_once $path;
            return;
        }
    }
} );

// ── Lifecycle hooks (must be top-level) ──────────────────────────────────────
register_activation_hook(   FG_LMS_FILE, [ 'FG_LMS_Installer', 'activate' ] );
register_deactivation_hook( FG_LMS_FILE, [ 'FG_LMS_Installer', 'deactivate' ] );

// ── Bootstrap ────────────────────────────────────────────────────────────────
/**
 * Returns the main plugin instance (singleton).
 */
function fg_lms(): FG_LMS_Plugin {
    return FG_LMS_Plugin::instance();
}

add_action( 'plugins_loaded', 'fg_lms' );
