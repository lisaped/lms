<?php
/**
 * Single lesson / quiz template.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
    the_post();

    $lesson_id = get_the_ID();
    $course_id = (int) get_post_meta( $lesson_id, '_fg_lms_course_id', true );
    $course    = $course_id ? get_post( $course_id ) : null;
    $user_id   = get_current_user_id();
    $is_enrolled = $user_id && $course_id && fg_lms()->enrollment->is_enrolled( $user_id, $course_id );
    $is_done     = $user_id && fg_lms()->progress->is_lesson_completed( $user_id, $lesson_id );

    // Sidebar: all lessons in this course.
    $lesson_ids = $course_id ? fg_lms()->progress->get_course_lesson_ids( $course_id ) : [];
    $progress   = $is_enrolled && $course_id ? fg_lms()->progress->get_course_progress( $user_id, $course_id ) : 0;

    // Next / prev navigation.
    $current_idx = array_search( $lesson_id, $lesson_ids, true );
    $prev_id     = ( false !== $current_idx && $current_idx > 0 ) ? $lesson_ids[ $current_idx - 1 ] : null;
    $next_id     = ( false !== $current_idx && isset( $lesson_ids[ $current_idx + 1 ] ) ) ? $lesson_ids[ $current_idx + 1 ] : null;
?>
<div class="fg-lms-lesson-layout">

    <!-- Sidebar: course curriculum -->
    <?php if ( $course ) : ?>
    <aside class="fg-lms-lesson-sidebar">
        <div class="fg-lms-sidebar-header">
            <a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="fg-lms-back-link">
                <span class="dashicons dashicons-arrow-left-alt"></span>
                <?php echo esc_html( $course->post_title ); ?>
            </a>
            <?php if ( $is_enrolled ) : ?>
            <div class="fg-lms-sidebar-progress">
                <div class="fg-lms-progress-bar fg-lms-progress-bar--sm" style="--fg-lms-pct:<?php echo esc_attr( $progress ); ?>%">
                    <span><?php echo esc_html( $progress ); ?>%</span>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <ol class="fg-lms-sidebar-list">
            <?php foreach ( $lesson_ids as $i => $lid ) :
                $l       = get_post( $lid );
                $done    = $user_id && fg_lms()->progress->is_lesson_completed( $user_id, $lid );
                $current = $lid === $lesson_id;
                $is_quiz = 'fg_quiz' === $l->post_type;
            ?>
            <li class="fg-lms-sidebar-item <?php echo $current ? 'fg-lms-sidebar-item--current' : ''; ?> <?php echo $done ? 'fg-lms-sidebar-item--done' : ''; ?>">
                <a href="<?php echo esc_url( get_permalink( $lid ) ); ?>">
                    <span class="dashicons <?php echo $done ? 'dashicons-yes-alt' : ( $is_quiz ? 'dashicons-welcome-write-blog' : 'dashicons-media-text' ); ?>"></span>
                    <span><?php echo esc_html( $l->post_title ); ?></span>
                </a>
            </li>
            <?php endforeach; ?>
        </ol>
    </aside>
    <?php endif; ?>

    <!-- Main lesson content -->
    <main class="fg-lms-lesson-main">
        <header class="fg-lms-lesson-header">
            <h1 class="fg-lms-lesson-title"><?php the_title(); ?></h1>
            <?php if ( $is_enrolled && $is_done ) : ?>
                <span class="fg-lms-badge fg-lms-badge--active">
                    <span class="dashicons dashicons-yes"></span> <?php esc_html_e( 'Completed', 'fg-lms' ); ?>
                </span>
            <?php endif; ?>
        </header>

        <div class="fg-lms-lesson-content">
            <?php the_content(); ?>
        </div>

        <?php if ( $is_enrolled ) : ?>
        <div class="fg-lms-lesson-footer">
            <!-- Mark complete button -->
            <?php if ( ! $is_done ) : ?>
            <form class="fg-lms-complete-form" method="post">
                <input type="hidden" name="fg_lms_action"    value="mark_lesson_complete">
                <input type="hidden" name="fg_lms_lesson_id" value="<?php echo esc_attr( $lesson_id ); ?>">
                <input type="hidden" name="fg_lms_course_id" value="<?php echo esc_attr( $course_id ); ?>">
                <input type="hidden" name="fg_lms_nonce"     value="<?php echo esc_attr( wp_create_nonce( 'fg_lms_public' ) ); ?>">
                <button type="submit" class="fg-lms-btn fg-lms-btn--success fg-lms-complete-btn">
                    <span class="dashicons dashicons-yes"></span>
                    <?php esc_html_e( 'Mark as Complete', 'fg-lms' ); ?>
                </button>
            </form>
            <?php endif; ?>

            <!-- Prev / Next navigation -->
            <div class="fg-lms-lesson-nav">
                <?php if ( $prev_id ) : ?>
                <a href="<?php echo esc_url( get_permalink( $prev_id ) ); ?>" class="fg-lms-btn fg-lms-btn--outline fg-lms-btn--sm">
                    &laquo; <?php esc_html_e( 'Previous', 'fg-lms' ); ?>
                </a>
                <?php endif; ?>

                <?php if ( $next_id ) : ?>
                <a href="<?php echo esc_url( get_permalink( $next_id ) ); ?>" class="fg-lms-btn fg-lms-btn--primary fg-lms-btn--sm fg-lms-next-btn">
                    <?php esc_html_e( 'Next', 'fg-lms' ); ?> &raquo;
                </a>
                <?php elseif ( $course_id ) : ?>
                <a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="fg-lms-btn fg-lms-btn--primary fg-lms-btn--sm">
                    <?php esc_html_e( 'Back to Course', 'fg-lms' ); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php else : ?>
        <div class="fg-lms-gate-message">
            <p><?php esc_html_e( 'You must be enrolled to access this lesson.', 'fg-lms' ); ?></p>
            <?php if ( $course_id ) : ?>
            <a href="<?php echo esc_url( get_permalink( $course_id ) ); ?>" class="fg-lms-btn fg-lms-btn--primary">
                <?php esc_html_e( 'View Course', 'fg-lms' ); ?>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </main>
</div>

<?php endwhile; ?>
<?php get_footer(); ?>
