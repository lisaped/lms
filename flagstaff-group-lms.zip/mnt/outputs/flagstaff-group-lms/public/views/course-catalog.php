<?php
/**
 * Course Catalog template — used for [fg_lms_catalog] shortcode and archive.
 *
 * Expected variable in scope when used as a shortcode template:
 *   $query (WP_Query)  — the courses query.
 *
 * When used as an archive template we run our own query.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

$is_archive = ! isset( $query );
if ( $is_archive ) {
    get_header();
    $query = new WP_Query( [
        'post_type'      => 'fg_course',
        'post_status'    => 'publish',
        'posts_per_page' => 12,
        'paged'          => get_query_var( 'paged', 1 ),
    ] );
}

$user_id       = get_current_user_id();
$brand_name    = esc_html( get_option( 'fg_lms_brand_name', 'Flagstaff Group LMS' ) );
$columns       = absint( $atts['columns'] ?? 3 );
$col_class     = 'fg-lms-col-' . min( 4, max( 1, $columns ) );
?>

<?php if ( $is_archive ) : ?>
<main class="fg-lms-wrap">
    <header class="fg-lms-catalog-header">
        <h1 class="fg-lms-catalog-title"><?php esc_html_e( 'Course Catalog', 'fg-lms' ); ?></h1>
        <p><?php echo esc_html( sprintf( __( 'Explore all courses offered by %s.', 'fg-lms' ), $brand_name ) ); ?></p>
    </header>
<?php endif; ?>

<div class="fg-lms-course-grid <?php echo esc_attr( $col_class ); ?>">
    <?php if ( $query->have_posts() ) :
        while ( $query->have_posts() ) : $query->the_post();
            $course_id    = get_the_ID();
            $lesson_count = count( fg_lms()->progress->get_course_lesson_ids( $course_id ) );
            $is_enrolled  = $user_id && fg_lms()->enrollment->is_enrolled( $user_id, $course_id );
            $progress     = $is_enrolled ? fg_lms()->progress->get_course_progress( $user_id, $course_id ) : 0;
            $cats         = get_the_terms( $course_id, 'fg_course_cat' );
            $cat_name     = $cats && ! is_wp_error( $cats ) ? esc_html( $cats[0]->name ) : '';
            $is_free      = (bool) get_post_meta( $course_id, '_fg_lms_is_free', true );
    ?>
        <article class="fg-lms-course-card <?php echo $is_enrolled ? 'fg-lms-course-card--enrolled' : ''; ?>">
            <?php if ( has_post_thumbnail() ) : ?>
            <a href="<?php the_permalink(); ?>" class="fg-lms-course-card__thumb">
                <?php the_post_thumbnail( 'medium_large' ); ?>
                <?php if ( $is_free ) : ?>
                <span class="fg-lms-badge fg-lms-badge--free"><?php esc_html_e( 'Free', 'fg-lms' ); ?></span>
                <?php endif; ?>
            </a>
            <?php endif; ?>

            <div class="fg-lms-course-card__body">
                <?php if ( $cat_name ) : ?>
                <span class="fg-lms-course-card__cat"><?php echo $cat_name; ?></span>
                <?php endif; ?>

                <h2 class="fg-lms-course-card__title">
                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                </h2>

                <p class="fg-lms-course-card__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>

                <div class="fg-lms-course-card__meta">
                    <span class="dashicons dashicons-book-alt"></span>
                    <?php echo esc_html( sprintf(
                        _n( '%d lesson', '%d lessons', $lesson_count, 'fg-lms' ),
                        $lesson_count
                    ) ); ?>
                </div>

                <?php if ( $is_enrolled ) : ?>
                <div class="fg-lms-progress-wrap fg-lms-progress-wrap--card">
                    <div class="fg-lms-progress-bar" style="--fg-lms-pct:<?php echo esc_attr( $progress ); ?>%">
                        <span><?php echo esc_html( $progress ); ?>%</span>
                    </div>
                </div>
                <?php endif; ?>

                <div class="fg-lms-course-card__footer">
                    <a href="<?php the_permalink(); ?>" class="fg-lms-btn fg-lms-btn--primary fg-lms-btn--sm">
                        <?php echo $is_enrolled
                            ? esc_html__( 'Continue', 'fg-lms' )
                            : esc_html__( 'View Course', 'fg-lms' ); ?>
                    </a>
                </div>
            </div>
        </article>
    <?php endwhile; ?>
    <?php else : ?>
        <p class="fg-lms-no-results"><?php esc_html_e( 'No courses found.', 'fg-lms' ); ?></p>
    <?php endif; ?>
    <?php wp_reset_postdata(); ?>
</div>

<?php if ( $is_archive ) :
    the_posts_pagination( [ 'prev_text' => '&laquo;', 'next_text' => '&raquo;' ] );
?>
</main>
<?php get_footer(); endif; ?>
