<?php
/**
 * Single course template.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
    the_post();

    $course_id   = get_the_ID();
    $user_id     = get_current_user_id();
    $is_enrolled = $user_id && fg_lms()->enrollment->is_enrolled( $user_id, $course_id );
    $progress    = $is_enrolled ? fg_lms()->progress->get_course_progress( $user_id, $course_id ) : 0;
    $lesson_ids  = fg_lms()->progress->get_course_lesson_ids( $course_id );
    $cats        = get_the_terms( $course_id, 'fg_course_cat' );
    $cert        = $is_enrolled && 100 === $progress
                    ? fg_lms()->certificate->get_certificate( $user_id, $course_id )
                    : null;
?>
<main class="fg-lms-wrap fg-lms-course-single">
    <div class="fg-lms-course-hero">
        <?php if ( has_post_thumbnail() ) : ?>
        <div class="fg-lms-course-hero__thumb"><?php the_post_thumbnail( 'large' ); ?></div>
        <?php endif; ?>
        <div class="fg-lms-course-hero__content">
            <?php if ( $cats && ! is_wp_error( $cats ) ) : ?>
            <div class="fg-lms-course-hero__cats">
                <?php foreach ( $cats as $cat ) : ?>
                <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>" class="fg-lms-cat-link"><?php echo esc_html( $cat->name ); ?></a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <h1 class="fg-lms-course-hero__title"><?php the_title(); ?></h1>
            <p class="fg-lms-course-hero__excerpt"><?php echo esc_html( get_the_excerpt() ); ?></p>

            <div class="fg-lms-course-hero__meta">
                <span><span class="dashicons dashicons-book-alt"></span> <?php echo esc_html( count( $lesson_ids ) ); ?> <?php esc_html_e( 'lessons', 'fg-lms' ); ?></span>
            </div>

            <?php if ( $is_enrolled ) : ?>
                <div class="fg-lms-progress-wrap" style="margin:16px 0">
                    <div class="fg-lms-progress-bar" style="--fg-lms-pct:<?php echo esc_attr( $progress ); ?>%">
                        <span><?php echo esc_html( $progress ); ?>% <?php esc_html_e( 'complete', 'fg-lms' ); ?></span>
                    </div>
                </div>
                <?php if ( $cert ) : ?>
                    <a href="<?php echo esc_url( fg_lms()->certificate->get_download_url( $cert->certificate_number ) ); ?>"
                       class="fg-lms-btn fg-lms-btn--success" target="_blank">
                        <span class="dashicons dashicons-awards"></span> <?php esc_html_e( 'Download Certificate', 'fg-lms' ); ?>
                    </a>
                <?php else : ?>
                    <?php $first = ! empty( $lesson_ids ) ? get_permalink( $lesson_ids[0] ) : '#'; ?>
                    <a href="<?php echo esc_url( $first ); ?>" class="fg-lms-btn fg-lms-btn--primary">
                        <?php esc_html_e( 'Continue Learning', 'fg-lms' ); ?>
                    </a>
                <?php endif; ?>
            <?php else : ?>
                <?php echo do_shortcode( '[fg_lms_enroll_button course_id="' . $course_id . '"]' ); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="fg-lms-course-body">
        <!-- Description -->
        <div class="fg-lms-course-description">
            <h2><?php esc_html_e( 'About This Course', 'fg-lms' ); ?></h2>
            <?php the_content(); ?>
        </div>

        <!-- Curriculum -->
        <div class="fg-lms-curriculum">
            <h2><?php esc_html_e( 'Curriculum', 'fg-lms' ); ?></h2>
            <?php if ( $lesson_ids ) : ?>
            <ol class="fg-lms-lesson-list">
                <?php foreach ( $lesson_ids as $i => $lid ) :
                    $lesson      = get_post( $lid );
                    $is_done     = $user_id && fg_lms()->progress->is_lesson_completed( $user_id, $lid );
                    $is_quiz     = 'fg_quiz' === $lesson->post_type;
                    $can_access  = $is_enrolled;
                ?>
                <li class="fg-lms-lesson-list__item <?php echo $is_done ? 'fg-lms-lesson-list__item--done' : ''; ?>">
                    <span class="fg-lms-lesson-list__num"><?php echo esc_html( $i + 1 ); ?></span>
                    <span class="dashicons <?php echo $is_done ? 'dashicons-yes-alt' : ( $is_quiz ? 'dashicons-welcome-write-blog' : 'dashicons-media-text' ); ?>"></span>
                    <?php if ( $can_access ) : ?>
                        <a href="<?php echo esc_url( get_permalink( $lid ) ); ?>" class="fg-lms-lesson-list__title">
                            <?php echo esc_html( $lesson->post_title ); ?>
                        </a>
                    <?php else : ?>
                        <span class="fg-lms-lesson-list__title fg-lms-lesson-list__title--locked">
                            <?php echo esc_html( $lesson->post_title ); ?>
                            <span class="dashicons dashicons-lock"></span>
                        </span>
                    <?php endif; ?>
                    <span class="fg-lms-lesson-list__type"><?php echo $is_quiz ? esc_html__( 'Quiz', 'fg-lms' ) : esc_html__( 'Lesson', 'fg-lms' ); ?></span>
                </li>
                <?php endforeach; ?>
            </ol>
            <?php else : ?>
                <p><?php esc_html_e( 'No lessons have been added to this course yet.', 'fg-lms' ); ?></p>
            <?php endif; ?>
        </div>
    </div>
</main>

<?php endwhile; ?>
<?php get_footer(); ?>
