<?php
/**
 * Student Dashboard view — rendered by [fg_lms_dashboard] shortcode.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

$user         = wp_get_current_user();
$enrollments  = fg_lms()->enrollment->get_user_enrollments( $user_id );
$membership   = fg_lms()->membership->get_user_active_membership( $user_id );
$certificates = fg_lms()->certificate->get_user_certificates( $user_id );

$active    = array_filter( $enrollments, fn( $e ) => 'active'    === $e->status );
$completed = array_filter( $enrollments, fn( $e ) => 'completed' === $e->status );
?>
<div class="fg-lms-dashboard">
    <!-- Welcome bar -->
    <div class="fg-lms-dashboard-welcome">
        <div class="fg-lms-dashboard-avatar">
            <?php echo get_avatar( $user->ID, 64, '', '', [ 'class' => 'fg-lms-avatar' ] ); ?>
        </div>
        <div>
            <h2><?php echo esc_html( sprintf( __( 'Welcome back, %s!', 'fg-lms' ), $user->display_name ) ); ?></h2>
            <?php if ( $membership ) : ?>
            <p class="fg-lms-membership-tag">
                <span class="dashicons dashicons-awards"></span>
                <?php echo esc_html( $membership->plan_name ); ?>
                &mdash;
                <?php echo $membership->expires_at
                    ? esc_html( sprintf( __( 'Active until %s', 'fg-lms' ), wp_date( get_option( 'date_format' ), strtotime( $membership->expires_at ) ) ) )
                    : esc_html__( 'Lifetime Membership', 'fg-lms' ); ?>
            </p>
            <?php else : ?>
            <p><?php esc_html_e( 'No active membership.', 'fg-lms' ); ?>
                <?php $plans_page = get_option( 'fg_lms_catalog_page_id' );
                if ( $plans_page ) : ?>
                <a href="<?php echo esc_url( get_permalink( $plans_page ) ); ?>"><?php esc_html_e( 'Browse Plans', 'fg-lms' ); ?></a>
                <?php endif; ?>
            </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Stats row -->
    <div class="fg-lms-dashboard-stats">
        <div class="fg-lms-stat-card fg-lms-stat-card--sm">
            <h3><?php echo esc_html( count( $active ) ); ?></h3>
            <p><?php esc_html_e( 'In Progress', 'fg-lms' ); ?></p>
        </div>
        <div class="fg-lms-stat-card fg-lms-stat-card--sm">
            <h3><?php echo esc_html( count( $completed ) ); ?></h3>
            <p><?php esc_html_e( 'Completed', 'fg-lms' ); ?></p>
        </div>
        <div class="fg-lms-stat-card fg-lms-stat-card--sm">
            <h3><?php echo esc_html( count( $certificates ) ); ?></h3>
            <p><?php esc_html_e( 'Certificates', 'fg-lms' ); ?></p>
        </div>
    </div>

    <!-- Active Courses -->
    <section class="fg-lms-dashboard-section">
        <h2><?php esc_html_e( 'My Courses', 'fg-lms' ); ?></h2>
        <?php if ( $enrollments ) : ?>
        <div class="fg-lms-dashboard-course-list">
            <?php foreach ( $enrollments as $enr ) :
                $cid      = (int) $enr->course_id;
                $pct      = fg_lms()->progress->get_course_progress( $user_id, $cid );
                $lessons  = fg_lms()->progress->get_course_lesson_ids( $cid );
                $thumb    = get_the_post_thumbnail_url( $cid, 'thumbnail' );
                $cert     = 'completed' === $enr->status ? fg_lms()->certificate->get_certificate( $user_id, $cid ) : null;
            ?>
            <div class="fg-lms-dashboard-course-card">
                <?php if ( $thumb ) : ?>
                <a href="<?php echo esc_url( get_permalink( $cid ) ); ?>" class="fg-lms-dashboard-course-card__thumb">
                    <img src="<?php echo esc_url( $thumb ); ?>" alt="">
                </a>
                <?php endif; ?>
                <div class="fg-lms-dashboard-course-card__body">
                    <h3>
                        <a href="<?php echo esc_url( get_permalink( $cid ) ); ?>"><?php echo esc_html( $enr->course_title ); ?></a>
                    </h3>
                    <div class="fg-lms-progress-wrap">
                        <div class="fg-lms-progress-bar" style="--fg-lms-pct:<?php echo esc_attr( $pct ); ?>%">
                            <span><?php echo esc_html( $pct ); ?>%</span>
                        </div>
                    </div>
                    <div class="fg-lms-dashboard-course-card__footer">
                        <a href="<?php echo esc_url( get_permalink( $cid ) ); ?>" class="fg-lms-btn fg-lms-btn--primary fg-lms-btn--sm">
                            <?php echo 100 === $pct ? esc_html__( 'Review', 'fg-lms' ) : esc_html__( 'Continue', 'fg-lms' ); ?>
                        </a>
                        <?php if ( $cert ) : ?>
                        <a href="<?php echo esc_url( fg_lms()->certificate->get_download_url( $cert->certificate_number ) ); ?>"
                           class="fg-lms-btn fg-lms-btn--outline fg-lms-btn--sm" target="_blank">
                            <span class="dashicons dashicons-awards"></span> <?php esc_html_e( 'Certificate', 'fg-lms' ); ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else : ?>
        <p><?php esc_html_e( 'You are not enrolled in any courses yet.', 'fg-lms' ); ?>
            <?php $catalog = get_option( 'fg_lms_catalog_page_id' );
            if ( $catalog ) : ?>
            <a href="<?php echo esc_url( get_permalink( $catalog ) ); ?>"><?php esc_html_e( 'Browse Courses', 'fg-lms' ); ?></a>
            <?php endif; ?>
        </p>
        <?php endif; ?>
    </section>

    <!-- Certificates -->
    <?php if ( $certificates ) : ?>
    <section class="fg-lms-dashboard-section">
        <h2><?php esc_html_e( 'My Certificates', 'fg-lms' ); ?></h2>
        <div class="fg-lms-cert-list">
            <?php foreach ( $certificates as $cert ) : ?>
            <div class="fg-lms-cert-item">
                <span class="dashicons dashicons-awards fg-lms-cert-icon"></span>
                <div>
                    <strong><?php echo esc_html( $cert->course_title ); ?></strong><br>
                    <small><?php echo esc_html( sprintf(
                        __( 'Issued %s', 'fg-lms' ),
                        wp_date( get_option( 'date_format' ), strtotime( $cert->issued_at ) )
                    ) ); ?></small>
                </div>
                <a href="<?php echo esc_url( fg_lms()->certificate->get_download_url( $cert->certificate_number ) ); ?>"
                   class="fg-lms-btn fg-lms-btn--outline fg-lms-btn--sm" target="_blank">
                    <?php esc_html_e( 'View', 'fg-lms' ); ?>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>
</div>
