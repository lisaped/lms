<?php
/**
 * Frontend controller — enqueues assets, handles form submissions, and
 * restricts content access based on membership.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Public {

    public function __construct() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'init',               [ $this, 'handle_form_submissions' ] );
        add_filter( 'the_content',        [ $this, 'maybe_gate_content' ] );
        add_action( 'template_redirect',  [ $this, 'redirect_after_enroll' ] );

        // Override single lesson/course templates.
        add_filter( 'single_template', [ $this, 'load_course_template' ] );
        add_filter( 'single_template', [ $this, 'load_lesson_template' ] );
        add_filter( 'archive_template', [ $this, 'load_catalog_template' ] );
    }

    // ── Assets ────────────────────────────────────────────────────────────────

    public function enqueue_assets(): void {
        wp_enqueue_style(
            'fg-lms-public',
            FG_LMS_URL . 'assets/css/public.css',
            [],
            FG_LMS_VERSION
        );

        wp_enqueue_script(
            'fg-lms-public',
            FG_LMS_URL . 'assets/js/public.js',
            [ 'jquery' ],
            FG_LMS_VERSION,
            true
        );

        $primary = get_option( 'fg_lms_primary_color', '#C8102E' );

        wp_localize_script( 'fg-lms-public', 'FG_LMS_Public', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'fg_lms_public' ),
            'primary'  => $primary,
            'i18n'     => [
                'mark_complete' => __( 'Mark Complete', 'fg-lms' ),
                'completed'     => __( 'Completed', 'fg-lms' ),
            ],
        ] );

        // Inline CSS custom properties for brand color.
        wp_add_inline_style( 'fg-lms-public', "
            :root {
                --fg-lms-primary:   {$primary};
                --fg-lms-secondary: " . esc_attr( get_option( 'fg_lms_secondary_color', '#1A1A1A' ) ) . ";
            }
        " );
    }

    // ── Form submissions ──────────────────────────────────────────────────────

    public function handle_form_submissions(): void {
        if ( empty( $_POST['fg_lms_action'] ) ) {
            return;
        }

        $action = sanitize_key( wp_unslash( $_POST['fg_lms_action'] ) );

        if ( 'enroll' === $action ) {
            $this->process_enroll();
        }

        if ( 'mark_lesson_complete' === $action ) {
            $this->process_mark_lesson_complete();
        }
    }

    private function process_enroll(): void {
        if ( ! is_user_logged_in() ) {
            wp_redirect( wp_login_url( wp_get_referer() ) );
            exit;
        }

        $course_id = absint( $_POST['fg_lms_course_id'] ?? 0 );

        if ( ! isset( $_POST['fg_lms_nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fg_lms_nonce'] ) ), 'fg_lms_enroll_' . $course_id ) ) {
            wp_die( esc_html__( 'Security check failed.', 'fg-lms' ) );
        }

        $user_id = get_current_user_id();

        if ( ! fg_lms()->membership->user_can_access_course( $user_id, $course_id ) &&
             ! get_post_meta( $course_id, '_fg_lms_is_free', true ) ) {
            wp_redirect( get_permalink( $course_id ) );
            exit;
        }

        fg_lms()->enrollment->enroll( $user_id, $course_id );

        $first_lesson_ids = fg_lms()->progress->get_course_lesson_ids( $course_id );
        $redirect = ! empty( $first_lesson_ids )
            ? get_permalink( $first_lesson_ids[0] )
            : get_permalink( $course_id );

        wp_redirect( $redirect );
        exit;
    }

    private function process_mark_lesson_complete(): void {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Not logged in.', 'fg-lms' ) ] );
        }

        $lesson_id = absint( $_POST['fg_lms_lesson_id'] ?? 0 );
        $course_id = absint( $_POST['fg_lms_course_id'] ?? 0 );

        if ( ! isset( $_POST['fg_lms_nonce'] ) ||
             ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['fg_lms_nonce'] ) ), 'fg_lms_public' ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'fg-lms' ) ] );
        }

        $user_id = get_current_user_id();

        // Verify enrollment.
        if ( ! fg_lms()->enrollment->is_enrolled( $user_id, $course_id ) ) {
            wp_send_json_error( [ 'message' => __( 'Not enrolled.', 'fg-lms' ) ] );
        }

        fg_lms()->progress->mark_lesson_complete( $user_id, $course_id, $lesson_id );

        $pct      = fg_lms()->progress->get_course_progress( $user_id, $course_id );
        $next_id  = $this->get_next_lesson_id( $course_id, $lesson_id );

        wp_send_json_success( [
            'progress'     => $pct,
            'next_url'     => $next_id ? get_permalink( $next_id ) : '',
            'course_url'   => get_permalink( $course_id ),
        ] );
    }

    // ── Content gating ────────────────────────────────────────────────────────

    public function maybe_gate_content( string $content ): string {
        if ( ! is_singular( [ 'fg_lesson', 'fg_quiz', 'fg_course' ] ) ) {
            return $content;
        }

        global $post;
        $user_id = get_current_user_id();

        if ( is_singular( 'fg_course' ) ) {
            return $this->gate_course_content( $content, $post, $user_id );
        }

        // Lessons / quizzes.
        $course_id = (int) get_post_meta( $post->ID, '_fg_lms_course_id', true );
        if ( ! $course_id ) {
            return $content;
        }

        if ( ! $user_id ) {
            return $this->gate_message( __( 'Please log in to access this lesson.', 'fg-lms' ), get_permalink( $course_id ) );
        }

        if ( ! fg_lms()->enrollment->is_enrolled( $user_id, $course_id ) ) {
            return $this->gate_message( __( 'You must be enrolled in this course to view this lesson.', 'fg-lms' ), get_permalink( $course_id ) );
        }

        return $content;
    }

    private function gate_course_content( string $content, WP_Post $post, int $user_id ): string {
        $is_free = (bool) get_post_meta( $post->ID, '_fg_lms_is_free', true );
        if ( $is_free ) {
            return $content;
        }

        if ( ! $user_id ) {
            return $content; // Shortcode [fg_lms_enroll_button] handles CTA.
        }

        return $content;
    }

    private function gate_message( string $message, string $back_url ): string {
        return sprintf(
            '<div class="fg-lms-gate-message">
                <p>%s</p>
                <a href="%s" class="fg-lms-btn fg-lms-btn--primary">%s</a>
             </div>',
            esc_html( $message ),
            esc_url( $back_url ),
            esc_html__( 'Go to Course', 'fg-lms' )
        );
    }

    public function redirect_after_enroll(): void {
        // placeholder for post-enroll redirect logic.
    }

    // ── Template overrides ───────────────────────────────────────────────────

    public function load_course_template( string $template ): string {
        if ( is_singular( 'fg_course' ) ) {
            $plugin_tpl = FG_LMS_DIR . 'public/views/course-single.php';
            if ( file_exists( $plugin_tpl ) ) {
                return $plugin_tpl;
            }
        }
        return $template;
    }

    public function load_lesson_template( string $template ): string {
        if ( is_singular( [ 'fg_lesson', 'fg_quiz' ] ) ) {
            $plugin_tpl = FG_LMS_DIR . 'public/views/lesson-single.php';
            if ( file_exists( $plugin_tpl ) ) {
                return $plugin_tpl;
            }
        }
        return $template;
    }

    public function load_catalog_template( string $template ): string {
        if ( is_post_type_archive( 'fg_course' ) ) {
            $plugin_tpl = FG_LMS_DIR . 'public/views/course-catalog.php';
            if ( file_exists( $plugin_tpl ) ) {
                return $plugin_tpl;
            }
        }
        return $template;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function get_next_lesson_id( int $course_id, int $current_lesson_id ): ?int {
        $ids = fg_lms()->progress->get_course_lesson_ids( $course_id );
        $idx = array_search( $current_lesson_id, $ids, true );
        return ( false !== $idx && isset( $ids[ $idx + 1 ] ) ) ? $ids[ $idx + 1 ] : null;
    }
}
