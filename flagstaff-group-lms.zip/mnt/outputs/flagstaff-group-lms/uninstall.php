<?php
/**
 * Uninstall — fires only when a user deletes the plugin from the admin.
 *
 * Removes:
 *  - All custom DB tables
 *  - All plugin options
 *  - (Optionally) all fg_course / fg_lesson / fg_quiz posts — see note below.
 *
 * @package FG_LMS
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Remove custom tables.
$tables = [
    $wpdb->prefix . 'fg_lms_plans',
    $wpdb->prefix . 'fg_lms_memberships',
    $wpdb->prefix . 'fg_lms_plan_courses',
    $wpdb->prefix . 'fg_lms_enrollments',
    $wpdb->prefix . 'fg_lms_progress',
    $wpdb->prefix . 'fg_lms_certificates',
];

foreach ( $tables as $table ) {
    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    $wpdb->query( "DROP TABLE IF EXISTS `$table`" );
}

// Remove options.
$options = [
    'fg_lms_db_version',
    'fg_lms_brand_name',
    'fg_lms_primary_color',
    'fg_lms_secondary_color',
    'fg_lms_catalog_page_id',
    'fg_lms_dashboard_page_id',
    'fg_lms_certificate_logo_url',
    'fg_lms_cert_signatory_name',
    'fg_lms_cert_signatory_title',
    'fg_lms_redirect_after_login',
];

foreach ( $options as $opt ) {
    delete_option( $opt );
}

/*
 * NOTE: We intentionally do NOT delete fg_course, fg_lesson, fg_quiz posts
 * here to prevent accidental content loss. If you want to purge content on
 * uninstall, uncomment the block below.
 */
/*
$post_types = [ 'fg_course', 'fg_lesson', 'fg_quiz', 'fg_question' ];
foreach ( $post_types as $pt ) {
    $ids = get_posts( [ 'post_type' => $pt, 'posts_per_page' => -1, 'fields' => 'ids' ] );
    foreach ( $ids as $id ) {
        wp_delete_post( $id, true );
    }
}
*/
