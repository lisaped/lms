/**
 * Flagstaff Group LMS — Admin JS
 *
 * Responsibilities:
 *   - Drag-and-drop lesson ordering in the Course Builder meta box
 *   - Color picker preview
 */
/* global jQuery, FG_LMS */
( function ( $ ) {
    'use strict';

    // ── Lesson sortable ──────────────────────────────────────────────────────

    $( function () {
        var $list = $( '#fg-lms-lesson-order' );

        if ( $list.length ) {
            $list.sortable( {
                handle:      '.fg-lms-drag-handle',
                placeholder: 'fg-lms-sortable-placeholder',
                axis:        'y',
                update:      function () {
                    // The hidden inputs' values are updated automatically
                    // because sortable reorders the DOM nodes.
                }
            } );
            $list.disableSelection();
        }

        // ── Confirm dangerous actions ────────────────────────────────────────

        $( document ).on( 'submit', '.fg-lms-confirm-form', function ( e ) {
            var msg = $( this ).data( 'confirm' ) || 'Are you sure?';
            if ( ! window.confirm( msg ) ) {
                e.preventDefault();
            }
        } );

        // ── Inline color preview ──────────────────────────────────────────────

        $( '#fg_lms_primary_color' ).on( 'input change', function () {
            $( ':root' ).css( '--fg-lms-primary', $( this ).val() );
        } );
    } );

} )( jQuery );
