/**
 * Flagstaff Group LMS — Public JS
 *
 * Responsibilities:
 *   - AJAX "Mark as Complete" for lessons (progressive enhancement)
 *   - Progress bar animation
 *   - Sticky sidebar scroll
 */
/* global jQuery, FG_LMS_Public */
( function ( $ ) {
    'use strict';

    $( function () {

        // ── Mark complete (AJAX) ─────────────────────────────────────────────

        $( '.fg-lms-complete-form' ).on( 'submit', function ( e ) {
            e.preventDefault();

            var $form = $( this );
            var $btn  = $form.find( '.fg-lms-complete-btn' );
            var data  = $form.serialize();

            $btn.addClass( 'is-loading' ).text( FG_LMS_Public.i18n.mark_complete + '…' );

            $.post( FG_LMS_Public.ajax_url, data )
                .done( function ( resp ) {
                    if ( resp.success ) {
                        $btn.removeClass( 'is-loading' )
                            .addClass( 'fg-lms-btn--success' )
                            .html( '<span class="dashicons dashicons-yes"></span> ' + FG_LMS_Public.i18n.completed );

                        // Update progress bars on the page.
                        var pct = resp.data.progress;
                        $( '.fg-lms-progress-bar' ).each( function () {
                            $( this ).css( '--fg-lms-pct', pct + '%' );
                            $( this ).find( 'span' ).text( pct + '%' );
                        } );
                        $( '.fg-lms-sidebar-progress .fg-lms-progress-bar' )
                            .css( '--fg-lms-pct', pct + '%' )
                            .find( 'span' ).text( pct + '%' );

                        // Mark sidebar item as done.
                        $( '.fg-lms-sidebar-item--current' ).addClass( 'fg-lms-sidebar-item--done' );

                        // Show next button if available.
                        if ( resp.data.next_url ) {
                            var $next = $( '.fg-lms-next-btn' );
                            if ( $next.length ) {
                                $next.attr( 'href', resp.data.next_url );
                            } else {
                                $( '.fg-lms-lesson-nav' ).append(
                                    '<a href="' + resp.data.next_url + '" class="fg-lms-btn fg-lms-btn--primary fg-lms-btn--sm">' +
                                    'Next &raquo;</a>'
                                );
                            }
                        }

                        // Disable the form after success.
                        $form.find( ':input' ).prop( 'disabled', true );
                    }
                } )
                .fail( function () {
                    $btn.removeClass( 'is-loading' ).text( FG_LMS_Public.i18n.mark_complete );
                    alert( 'An error occurred. Please try again.' );
                } );
        } );

        // ── Animate progress bars on page load ───────────────────────────────

        $( '.fg-lms-progress-bar' ).each( function () {
            var $bar = $( this );
            var pct  = $bar.css( '--fg-lms-pct' ) || '0%';
            $bar.css( '--fg-lms-pct', '0%' );
            setTimeout( function () {
                $bar.css( 'transition', 'width .6s ease' );
                $bar.css( '--fg-lms-pct', pct );
            }, 150 );
        } );

        // ── Sticky sidebar on lesson pages ───────────────────────────────────

        var $sidebar = $( '.fg-lms-lesson-sidebar' );
        if ( $sidebar.length ) {
            // Sidebar already uses position:sticky via CSS; highlight current.
            var $current = $sidebar.find( '.fg-lms-sidebar-item--current' );
            if ( $current.length ) {
                $current[0].scrollIntoView( { block: 'center', behavior: 'smooth' } );
            }
        }

    } );

} )( jQuery );
