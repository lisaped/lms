<?php
/**
 * Handles plugin activation, deactivation, and DB schema creation/upgrades.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Installer {

    // ── Lifecycle ────────────────────────────────────────────────────────────

    public static function activate(): void {
        // Register CPTs before flushing rewrite rules.
        require_once FG_LMS_DIR . 'includes/class-fg-lms-cpt.php';
        ( new FG_LMS_CPT() )->register();

        self::create_tables();
        self::set_default_options();

        flush_rewrite_rules();
        update_option( 'fg_lms_db_version', FG_LMS_DB_VERSION );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }

    public static function maybe_upgrade(): void {
        $installed = get_option( 'fg_lms_db_version', '0' );
        if ( version_compare( $installed, FG_LMS_DB_VERSION, '<' ) ) {
            self::create_tables();
            update_option( 'fg_lms_db_version', FG_LMS_DB_VERSION );
        }
    }

    // ── Database schema ──────────────────────────────────────────────────────

    private static function create_tables(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Membership plans.
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_plans (
                id            BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                name          VARCHAR(200) NOT NULL DEFAULT '',
                description   TEXT NOT NULL,
                price         DECIMAL(10,2) NOT NULL DEFAULT '0.00',
                duration_days INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '0 = lifetime',
                course_access ENUM('all','specific') NOT NULL DEFAULT 'all',
                status        ENUM('active','inactive') NOT NULL DEFAULT 'active',
                created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id)
            ) $charset;
        " );

        // User memberships (subscriptions).
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_memberships (
                id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id    BIGINT(20) UNSIGNED NOT NULL,
                plan_id    BIGINT(20) UNSIGNED NOT NULL,
                status     ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
                started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME DEFAULT NULL COMMENT 'NULL = lifetime',
                PRIMARY KEY (id),
                KEY user_id  (user_id),
                KEY plan_id  (plan_id),
                KEY status   (status)
            ) $charset;
        " );

        // Plan → specific course access mapping.
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_plan_courses (
                plan_id   BIGINT(20) UNSIGNED NOT NULL,
                course_id BIGINT(20) UNSIGNED NOT NULL,
                PRIMARY KEY (plan_id, course_id)
            ) $charset;
        " );

        // Course enrollments.
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_enrollments (
                id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id      BIGINT(20) UNSIGNED NOT NULL,
                course_id    BIGINT(20) UNSIGNED NOT NULL,
                status       ENUM('active','completed','expired') NOT NULL DEFAULT 'active',
                enrolled_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                completed_at DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY user_course (user_id, course_id),
                KEY user_id   (user_id),
                KEY course_id (course_id),
                KEY status    (status)
            ) $charset;
        " );

        // Lesson / quiz progress.
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_progress (
                id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id      BIGINT(20) UNSIGNED NOT NULL,
                course_id    BIGINT(20) UNSIGNED NOT NULL,
                lesson_id    BIGINT(20) UNSIGNED NOT NULL,
                status       ENUM('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
                score        TINYINT UNSIGNED DEFAULT NULL COMMENT 'Quiz score 0-100, NULL for lessons',
                completed_at DATETIME DEFAULT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY user_lesson (user_id, lesson_id),
                KEY user_id   (user_id),
                KEY course_id (course_id)
            ) $charset;
        " );

        // Issued certificates.
        dbDelta( "
            CREATE TABLE {$wpdb->prefix}fg_lms_certificates (
                id                 BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                user_id            BIGINT(20) UNSIGNED NOT NULL,
                course_id          BIGINT(20) UNSIGNED NOT NULL,
                certificate_number VARCHAR(64) NOT NULL,
                issued_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY user_course (user_id, course_id),
                UNIQUE KEY cert_number (certificate_number),
                KEY user_id   (user_id),
                KEY course_id (course_id)
            ) $charset;
        " );
    }

    // ── Default plugin options ────────────────────────────────────────────────

    private static function set_default_options(): void {
        $defaults = [
            'fg_lms_primary_color'        => '#C8102E',
            'fg_lms_secondary_color'      => '#1A1A1A',
            'fg_lms_brand_name'           => 'Flagstaff Group LMS',
            'fg_lms_catalog_page_id'      => 0,
            'fg_lms_dashboard_page_id'    => 0,
            'fg_lms_certificate_logo_url' => '',
            'fg_lms_cert_signatory_name'  => '',
            'fg_lms_cert_signatory_title' => '',
            'fg_lms_redirect_after_login' => '',
        ];
        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $value );
            }
        }
    }
}
