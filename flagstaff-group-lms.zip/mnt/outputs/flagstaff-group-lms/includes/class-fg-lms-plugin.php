<?php
/**
 * Core plugin class — wires together all subsystems.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

final class FG_LMS_Plugin {

    /** @var FG_LMS_Plugin|null Singleton instance */
    private static ?FG_LMS_Plugin $instance = null;

    /** Sub-system references */
    public FG_LMS_CPT        $cpt;
    public FG_LMS_Enrollment $enrollment;
    public FG_LMS_Membership $membership;
    public FG_LMS_Progress   $progress;
    public FG_LMS_Certificate $certificate;
    public FG_LMS_Shortcodes $shortcodes;

    private function __construct() {
        $this->load_textdomain();
        $this->init_subsystems();
        $this->register_hooks();
    }

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function load_textdomain(): void {
        load_plugin_textdomain(
            'fg-lms',
            false,
            dirname( FG_LMS_BASENAME ) . '/languages'
        );
    }

    private function init_subsystems(): void {
        require_once FG_LMS_DIR . 'includes/class-fg-lms-installer.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-cpt.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-enrollment.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-membership.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-progress.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-certificate.php';
        require_once FG_LMS_DIR . 'includes/class-fg-lms-shortcodes.php';

        $this->cpt         = new FG_LMS_CPT();
        $this->enrollment  = new FG_LMS_Enrollment();
        $this->membership  = new FG_LMS_Membership();
        $this->progress    = new FG_LMS_Progress();
        $this->certificate = new FG_LMS_Certificate();
        $this->shortcodes  = new FG_LMS_Shortcodes();

        if ( is_admin() ) {
            require_once FG_LMS_DIR . 'admin/class-fg-lms-admin.php';
            new FG_LMS_Admin();
        } else {
            require_once FG_LMS_DIR . 'public/class-fg-lms-public.php';
            new FG_LMS_Public();
        }
    }

    private function register_hooks(): void {
        add_action( 'init', [ $this->cpt, 'register' ] );
        add_action( 'init', [ $this->shortcodes, 'register' ] );

        // DB upgrade check on each load.
        add_action( 'init', [ 'FG_LMS_Installer', 'maybe_upgrade' ] );
    }
}
