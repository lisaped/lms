<?php
/**
 * Registers Custom Post Types and Taxonomies.
 *
 * CPTs:   fg_course | fg_lesson | fg_quiz | fg_question
 * Taxos:  fg_course_cat | fg_course_tag
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_CPT {

    public function register(): void {
        $this->register_course();
        $this->register_lesson();
        $this->register_quiz();
        $this->register_question();
        $this->register_taxonomies();
    }

    // ── Course ───────────────────────────────────────────────────────────────

    private function register_course(): void {
        register_post_type( 'fg_course', [
            'labels'              => $this->labels(
                __( 'Course', 'fg-lms' ),
                __( 'Courses', 'fg-lms' )
            ),
            'public'              => true,
            'show_in_menu'        => false, // added manually via admin class
            'show_in_rest'        => true,
            'supports'            => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
            'has_archive'         => 'courses',
            'rewrite'             => [ 'slug' => 'courses', 'with_front' => false ],
            'menu_icon'           => 'dashicons-welcome-learn-more',
            'capability_type'     => 'post',
            'map_meta_cap'        => true,
        ] );
    }

    // ── Lesson ───────────────────────────────────────────────────────────────

    private function register_lesson(): void {
        register_post_type( 'fg_lesson', [
            'labels'          => $this->labels(
                __( 'Lesson', 'fg-lms' ),
                __( 'Lessons', 'fg-lms' )
            ),
            'public'          => true,
            'show_in_menu'    => false,
            'show_in_rest'    => true,
            'supports'        => [ 'title', 'editor', 'custom-fields' ],
            'has_archive'     => false,
            'rewrite'         => [ 'slug' => 'lessons', 'with_front' => false ],
            'capability_type' => 'post',
            'map_meta_cap'    => true,
        ] );
    }

    // ── Quiz ─────────────────────────────────────────────────────────────────

    private function register_quiz(): void {
        register_post_type( 'fg_quiz', [
            'labels'          => $this->labels(
                __( 'Quiz', 'fg-lms' ),
                __( 'Quizzes', 'fg-lms' )
            ),
            'public'          => true,
            'show_in_menu'    => false,
            'show_in_rest'    => true,
            'supports'        => [ 'title', 'custom-fields' ],
            'has_archive'     => false,
            'rewrite'         => [ 'slug' => 'quizzes', 'with_front' => false ],
            'capability_type' => 'post',
            'map_meta_cap'    => true,
        ] );
    }

    // ── Question ─────────────────────────────────────────────────────────────

    private function register_question(): void {
        register_post_type( 'fg_question', [
            'labels'          => $this->labels(
                __( 'Question', 'fg-lms' ),
                __( 'Questions', 'fg-lms' )
            ),
            'public'          => false,
            'show_in_menu'    => false,
            'show_in_rest'    => true,
            'supports'        => [ 'title', 'editor', 'custom-fields' ],
            'capability_type' => 'post',
            'map_meta_cap'    => true,
        ] );
    }

    // ── Taxonomies ───────────────────────────────────────────────────────────

    private function register_taxonomies(): void {
        // Course Category (hierarchical).
        register_taxonomy( 'fg_course_cat', 'fg_course', [
            'labels'            => [
                'name'          => __( 'Course Categories', 'fg-lms' ),
                'singular_name' => __( 'Course Category', 'fg-lms' ),
                'menu_name'     => __( 'Categories', 'fg-lms' ),
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_in_rest'      => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'course-category' ],
        ] );

        // Course Tag (flat).
        register_taxonomy( 'fg_course_tag', 'fg_course', [
            'labels'        => [
                'name'          => __( 'Course Tags', 'fg-lms' ),
                'singular_name' => __( 'Course Tag', 'fg-lms' ),
                'menu_name'     => __( 'Tags', 'fg-lms' ),
            ],
            'hierarchical'  => false,
            'show_ui'       => true,
            'show_in_rest'  => true,
            'rewrite'       => [ 'slug' => 'course-tag' ],
        ] );
    }

    // ── Helper ───────────────────────────────────────────────────────────────

    private function labels( string $singular, string $plural ): array {
        return [
            'name'               => $plural,
            'singular_name'      => $singular,
            'add_new'            => __( 'Add New', 'fg-lms' ),
            /* translators: %s: post type singular name */
            'add_new_item'       => sprintf( __( 'Add New %s', 'fg-lms' ), $singular ),
            /* translators: %s: post type singular name */
            'edit_item'          => sprintf( __( 'Edit %s', 'fg-lms' ), $singular ),
            /* translators: %s: post type singular name */
            'new_item'           => sprintf( __( 'New %s', 'fg-lms' ), $singular ),
            /* translators: %s: post type plural name */
            'view_item'          => sprintf( __( 'View %s', 'fg-lms' ), $singular ),
            'search_items'       => sprintf( __( 'Search %s', 'fg-lms' ), $plural ),
            'not_found'          => sprintf( __( 'No %s found', 'fg-lms' ), strtolower( $plural ) ),
            'not_found_in_trash' => sprintf( __( 'No %s in Trash', 'fg-lms' ), strtolower( $plural ) ),
            'menu_name'          => $plural,
        ];
    }
}
