<?php
/**
 * Membership / Subscription system.
 *
 * Plans define what a subscriber can access and for how long.
 * Memberships link users to plans.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Membership {

    // ── Plans CRUD ────────────────────────────────────────────────────────────

    /**
     * Create or update a membership plan.
     *
     * @param array $data {
     *   name, description, price, duration_days, course_access ('all'|'specific'), status
     * }
     * @param int   $id   0 = insert, >0 = update.
     * @return int|false  New plan ID or false on failure.
     */
    public function save_plan( array $data, int $id = 0 ): int|false {
        global $wpdb;
        $table  = $wpdb->prefix . 'fg_lms_plans';
        $fields = [
            'name'          => sanitize_text_field( $data['name'] ?? '' ),
            'description'   => wp_kses_post( $data['description'] ?? '' ),
            'price'         => (float) ( $data['price'] ?? 0 ),
            'duration_days' => absint( $data['duration_days'] ?? 0 ),
            'course_access' => in_array( $data['course_access'] ?? '', [ 'all', 'specific' ], true )
                                ? $data['course_access'] : 'all',
            'status'        => in_array( $data['status'] ?? '', [ 'active', 'inactive' ], true )
                                ? $data['status'] : 'active',
        ];

        if ( $id > 0 ) {
            $result = $wpdb->update( $table, $fields, [ 'id' => $id ], null, [ '%d' ] );
            return false !== $result ? $id : false;
        }

        $result = $wpdb->insert( $table, $fields );
        return $result ? (int) $wpdb->insert_id : false;
    }

    /** @return object|null */
    public function get_plan( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_plans WHERE id = %d",
                $id
            )
        );
    }

    /** @return object[] */
    public function get_plans( string $status = 'active' ): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_plans WHERE status = %s ORDER BY price ASC",
                $status
            )
        );
    }

    public function delete_plan( int $id ): bool {
        global $wpdb;
        $result = $wpdb->delete( $wpdb->prefix . 'fg_lms_plans', [ 'id' => $id ], [ '%d' ] );
        if ( $result ) {
            $wpdb->delete( $wpdb->prefix . 'fg_lms_plan_courses', [ 'plan_id' => $id ], [ '%d' ] );
        }
        return (bool) $result;
    }

    // ── Plan course mapping ───────────────────────────────────────────────────

    public function set_plan_courses( int $plan_id, array $course_ids ): void {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_lms_plan_courses';
        $wpdb->delete( $table, [ 'plan_id' => $plan_id ], [ '%d' ] );
        foreach ( array_unique( array_map( 'absint', $course_ids ) ) as $cid ) {
            if ( $cid > 0 ) {
                $wpdb->replace( $table, [ 'plan_id' => $plan_id, 'course_id' => $cid ], [ '%d', '%d' ] );
            }
        }
    }

    /** @return int[] */
    public function get_plan_course_ids( int $plan_id ): array {
        global $wpdb;
        return array_map( 'intval',
            $wpdb->get_col(
                $wpdb->prepare(
                    "SELECT course_id FROM {$wpdb->prefix}fg_lms_plan_courses WHERE plan_id = %d",
                    $plan_id
                )
            )
        );
    }

    // ── User memberships ──────────────────────────────────────────────────────

    /**
     * Subscribe a user to a plan.
     *
     * @return int|false  Membership row ID or false on failure.
     */
    public function subscribe( int $user_id, int $plan_id ): int|false {
        global $wpdb;

        $plan = $this->get_plan( $plan_id );
        if ( ! $plan ) {
            return false;
        }

        $expires_at = null;
        if ( (int) $plan->duration_days > 0 ) {
            $expires_at = gmdate( 'Y-m-d H:i:s',
                strtotime( "+{$plan->duration_days} days" )
            );
        }

        // Cancel any existing active memberships first.
        $wpdb->update(
            $wpdb->prefix . 'fg_lms_memberships',
            [ 'status' => 'cancelled' ],
            [ 'user_id' => $user_id, 'status' => 'active' ],
            [ '%s' ],
            [ '%d', '%s' ]
        );

        $result = $wpdb->insert(
            $wpdb->prefix . 'fg_lms_memberships',
            [
                'user_id'    => $user_id,
                'plan_id'    => $plan_id,
                'status'     => 'active',
                'started_at' => current_time( 'mysql', true ),
                'expires_at' => $expires_at,
            ],
            [ '%d', '%d', '%s', '%s', '%s' ]
        );

        if ( ! $result ) {
            return false;
        }

        $membership_id = (int) $wpdb->insert_id;

        /**
         * Fires after a user is successfully subscribed to a plan.
         *
         * @param int $user_id       The subscriber.
         * @param int $plan_id       The plan.
         * @param int $membership_id The new membership row ID.
         */
        do_action( 'fg_lms_user_subscribed', $user_id, $plan_id, $membership_id );

        return $membership_id;
    }

    public function cancel_membership( int $membership_id ): bool {
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'fg_lms_memberships',
            [ 'status' => 'cancelled' ],
            [ 'id' => $membership_id ],
            [ '%s' ],
            [ '%d' ]
        );
        return (bool) $result;
    }

    /** @return object|null */
    public function get_user_active_membership( int $user_id ): ?object {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT m.*, p.name AS plan_name, p.course_access
                   FROM {$wpdb->prefix}fg_lms_memberships m
                   JOIN {$wpdb->prefix}fg_lms_plans p ON p.id = m.plan_id
                  WHERE m.user_id = %d
                    AND m.status  = 'active'
                    AND ( m.expires_at IS NULL OR m.expires_at > UTC_TIMESTAMP() )
                  ORDER BY m.started_at DESC
                  LIMIT 1",
                $user_id
            )
        );
    }

    /** @return object[] */
    public function get_user_membership_history( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT m.*, p.name AS plan_name
                   FROM {$wpdb->prefix}fg_lms_memberships m
                   JOIN {$wpdb->prefix}fg_lms_plans p ON p.id = m.plan_id
                  WHERE m.user_id = %d
                  ORDER BY m.started_at DESC",
                $user_id
            )
        );
    }

    /**
     * Check whether a user has active access to a specific course.
     */
    public function user_can_access_course( int $user_id, int $course_id ): bool {
        // Admins always pass.
        if ( user_can( $user_id, 'manage_options' ) ) {
            return true;
        }

        $membership = $this->get_user_active_membership( $user_id );
        if ( ! $membership ) {
            return false;
        }

        if ( 'all' === $membership->course_access ) {
            return true;
        }

        // Specific: check plan_courses mapping.
        $allowed_ids = $this->get_plan_course_ids( (int) $membership->plan_id );
        return in_array( $course_id, $allowed_ids, true );
    }

    /**
     * Auto-expire memberships whose expires_at has passed.
     * Intended to be called from a WP-Cron job.
     */
    public function expire_memberships(): void {
        global $wpdb;
        $wpdb->query(
            "UPDATE {$wpdb->prefix}fg_lms_memberships
                SET status = 'expired'
              WHERE status = 'active'
                AND expires_at IS NOT NULL
                AND expires_at <= UTC_TIMESTAMP()"
        );
    }
}
