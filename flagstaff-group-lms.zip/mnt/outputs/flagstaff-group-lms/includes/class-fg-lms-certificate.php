<?php
/**
 * Certificate generation and management.
 *
 * Certificates are auto-issued on the 'fg_lms_course_completed' action.
 * They can be rendered as HTML (for print/PDF) and downloaded.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Certificate {

    public function __construct() {
        // Auto-issue when a course is completed.
        add_action( 'fg_lms_course_completed', [ $this, 'issue_certificate' ], 10, 2 );

        // Download endpoint: ?fg_lms_cert=<cert_number>&uid=<user_id>
        add_action( 'init', [ $this, 'handle_download_request' ] );
    }

    // ── Issuance ──────────────────────────────────────────────────────────────

    /**
     * Issue a certificate (idempotent — one cert per user per course).
     *
     * @return int|false  Certificate row ID, or false on failure / already issued.
     */
    public function issue_certificate( int $user_id, int $course_id ): int|false {
        global $wpdb;

        // Already issued?
        if ( $this->get_certificate( $user_id, $course_id ) ) {
            return false;
        }

        $cert_number = $this->generate_certificate_number( $user_id, $course_id );

        $result = $wpdb->insert(
            $wpdb->prefix . 'fg_lms_certificates',
            [
                'user_id'            => $user_id,
                'course_id'          => $course_id,
                'certificate_number' => $cert_number,
                'issued_at'          => current_time( 'mysql', true ),
            ],
            [ '%d', '%d', '%s', '%s' ]
        );

        if ( ! $result ) {
            return false;
        }

        $cert_id = (int) $wpdb->insert_id;
        do_action( 'fg_lms_certificate_issued', $user_id, $course_id, $cert_number );
        return $cert_id;
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    /** @return object|null */
    public function get_certificate( int $user_id, int $course_id ): ?object {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_certificates
                  WHERE user_id = %d AND course_id = %d",
                $user_id,
                $course_id
            )
        );
    }

    /** @return object|null */
    public function get_certificate_by_number( string $cert_number ): ?object {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_certificates
                  WHERE certificate_number = %s",
                sanitize_text_field( $cert_number )
            )
        );
    }

    /**
     * @return object[]
     */
    public function get_user_certificates( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT c.*, p.post_title AS course_title
                   FROM {$wpdb->prefix}fg_lms_certificates c
                   JOIN {$wpdb->posts} p ON p.ID = c.course_id
                  WHERE c.user_id = %d
                  ORDER BY c.issued_at DESC",
                $user_id
            )
        );
    }

    // ── Download endpoint ─────────────────────────────────────────────────────

    public function handle_download_request(): void {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( empty( $_GET['fg_lms_cert'] ) ) {
            return;
        }

        if ( ! is_user_logged_in() ) {
            auth_redirect();
        }

        $cert_number = sanitize_text_field( wp_unslash( $_GET['fg_lms_cert'] ) );
        $cert        = $this->get_certificate_by_number( $cert_number );

        if ( ! $cert ) {
            wp_die( esc_html__( 'Certificate not found.', 'fg-lms' ), 404 );
        }

        // Ensure the current user owns this cert (or is admin).
        $current_user_id = get_current_user_id();
        if ( (int) $cert->user_id !== $current_user_id && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have permission to view this certificate.', 'fg-lms' ), 403 );
        }

        $this->render_certificate_html( $cert );
        exit;
    }

    // ── HTML render ───────────────────────────────────────────────────────────

    /**
     * Output the full HTML certificate page (browser-printable, PDF-ready).
     */
    public function render_certificate_html( object $cert ): void {
        $user        = get_userdata( (int) $cert->user_id );
        $course      = get_post( (int) $cert->course_id );
        $brand_name  = esc_html( get_option( 'fg_lms_brand_name', 'Flagstaff Group LMS' ) );
        $logo_url    = esc_url( get_option( 'fg_lms_certificate_logo_url', '' ) );
        $signatory   = esc_html( get_option( 'fg_lms_cert_signatory_name', '' ) );
        $sign_title  = esc_html( get_option( 'fg_lms_cert_signatory_title', '' ) );
        $primary     = esc_attr( get_option( 'fg_lms_primary_color', '#C8102E' ) );
        $issued_date = wp_date( get_option( 'date_format' ), strtotime( $cert->issued_at ) );

        include FG_LMS_DIR . 'templates/certificate-template.php';
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public function get_download_url( string $cert_number ): string {
        return add_query_arg( 'fg_lms_cert', rawurlencode( $cert_number ), home_url( '/' ) );
    }

    private function generate_certificate_number( int $user_id, int $course_id ): string {
        return strtoupper(
            'FG-' . base_convert( $user_id, 10, 36 )
            . '-' . base_convert( $course_id, 10, 36 )
            . '-' . base_convert( time(), 10, 36 )
            . '-' . substr( wp_generate_uuid4(), 0, 4 )
        );
    }
}
