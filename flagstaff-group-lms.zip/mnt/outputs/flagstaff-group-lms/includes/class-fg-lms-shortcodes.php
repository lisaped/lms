<?php
/**
 * Shortcodes for embedding LMS elements in page/post content.
 *
 * [fg_lms_catalog]           – Course catalog grid
 * [fg_lms_dashboard]         – Student dashboard
 * [fg_lms_course_progress]   – Progress bar for current/specific course
 * [fg_lms_enroll_button]     – Enrollment CTA
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Shortcodes {

    public function register(): void {
        add_shortcode( 'fg_lms_catalog',         [ $this, 'sc_catalog' ] );
        add_shortcode( 'fg_lms_dashboard',        [ $this, 'sc_dashboard' ] );
        add_shortcode( 'fg_lms_course_progress',  [ $this, 'sc_course_progress' ] );
        add_shortcode( 'fg_lms_enroll_button',    [ $this, 'sc_enroll_button' ] );
    }

    // ── [fg_lms_catalog] ──────────────────────────────────────────────────────

    public function sc_catalog( array $atts ): string {
        $atts = shortcode_atts( [
            'columns'  => 3,
            'per_page' => 12,
            'category' => '',
        ], $atts, 'fg_lms_catalog' );

        $args = [
            'post_type'      => 'fg_course',
            'post_status'    => 'publish',
            'posts_per_page' => absint( $atts['per_page'] ),
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if ( $atts['category'] ) {
            $args['tax_query'] = [ [
                'taxonomy' => 'fg_course_cat',
                'field'    => 'slug',
                'terms'    => sanitize_text_field( $atts['category'] ),
            ] ];
        }

        $query = new WP_Query( $args );

        ob_start();
        include FG_LMS_DIR . 'public/views/course-catalog.php';
        wp_reset_postdata();
        return ob_get_clean();
    }

    // ── [fg_lms_dashboard] ───────────────────────────────────────────────────

    public function sc_dashboard( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="fg-lms-notice">' .
                   esc_html__( 'Please log in to view your dashboard.', 'fg-lms' ) .
                   '</p>';
        }

        $user_id = get_current_user_id();
        ob_start();
        include FG_LMS_DIR . 'public/views/student-dashboard.php';
        return ob_get_clean();
    }

    // ── [fg_lms_course_progress] ─────────────────────────────────────────────

    public function sc_course_progress( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '';
        }

        $atts      = shortcode_atts( [ 'course_id' => 0 ], $atts, 'fg_lms_course_progress' );
        $user_id   = get_current_user_id();
        $course_id = absint( $atts['course_id'] ) ?: get_the_ID();
        $pct       = fg_lms()->progress->get_course_progress( $user_id, $course_id );

        ob_start();
        ?>
        <div class="fg-lms-progress-wrap">
            <div class="fg-lms-progress-bar" role="progressbar"
                 aria-valuenow="<?php echo esc_attr( $pct ); ?>"
                 aria-valuemin="0" aria-valuemax="100"
                 style="--fg-lms-pct:<?php echo esc_attr( $pct ); ?>%">
                <span><?php echo esc_html( $pct ); ?>%</span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

    // ── [fg_lms_enroll_button] ───────────────────────────────────────────────

    public function sc_enroll_button( array $atts ): string {
        $atts      = shortcode_atts( [ 'course_id' => 0 ], $atts, 'fg_lms_enroll_button' );
        $course_id = absint( $atts['course_id'] ) ?: get_the_ID();
        $user_id   = get_current_user_id();

        if ( ! $user_id ) {
            return sprintf(
                '<a href="%s" class="fg-lms-btn fg-lms-btn--primary">%s</a>',
                esc_url( wp_login_url( get_permalink( $course_id ) ) ),
                esc_html__( 'Log in to Enroll', 'fg-lms' )
            );
        }

        if ( fg_lms()->enrollment->is_enrolled( $user_id, $course_id ) ) {
            $first_lesson = fg_lms()->progress->get_course_lesson_ids( $course_id )[0] ?? 0;
            return sprintf(
                '<a href="%s" class="fg-lms-btn fg-lms-btn--primary">%s</a>',
                esc_url( $first_lesson ? get_permalink( $first_lesson ) : '#' ),
                esc_html__( 'Continue Learning', 'fg-lms' )
            );
        }

        if ( ! fg_lms()->membership->user_can_access_course( $user_id, $course_id ) ) {
            $plans_url = get_option( 'fg_lms_catalog_page_id' )
                ? get_permalink( (int) get_option( 'fg_lms_catalog_page_id' ) ) : '#';
            return sprintf(
                '<a href="%s" class="fg-lms-btn fg-lms-btn--outline">%s</a>',
                esc_url( $plans_url ),
                esc_html__( 'View Membership Plans', 'fg-lms' )
            );
        }

        // Has access, not enrolled — show enroll button with nonce.
        $nonce = wp_create_nonce( 'fg_lms_enroll_' . $course_id );
        return sprintf(
            '<form method="post" class="fg-lms-enroll-form">
                <input type="hidden" name="fg_lms_action"    value="enroll">
                <input type="hidden" name="fg_lms_course_id" value="%d">
                <input type="hidden" name="fg_lms_nonce"     value="%s">
                <button type="submit" class="fg-lms-btn fg-lms-btn--primary">%s</button>
             </form>',
            esc_attr( $course_id ),
            esc_attr( $nonce ),
            esc_html__( 'Enroll Now', 'fg-lms' )
        );
    }
}
