<?php
/**
 * Student progress tracking.
 *
 * Tracks per-lesson and per-quiz completion, and rolls up to course-level
 * progress percentage. Fires completion hooks that trigger certificate issuance.
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Progress {

    // ── Mark lesson / quiz status ────────────────────────────────────────────

    /**
     * Mark a lesson as completed by a user.
     *
     * @param int      $user_id
     * @param int      $course_id
     * @param int      $lesson_id   Post ID of fg_lesson or fg_quiz.
     * @param int|null $score       Pass score (0-100) for quizzes, null for lessons.
     */
    public function mark_lesson_complete(
        int $user_id,
        int $course_id,
        int $lesson_id,
        ?int $score = null
    ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_lms_progress';

        $existing = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT id, status FROM $table WHERE user_id = %d AND lesson_id = %d",
                $user_id,
                $lesson_id
            )
        );

        $data = [
            'user_id'      => $user_id,
            'course_id'    => $course_id,
            'lesson_id'    => $lesson_id,
            'status'       => 'completed',
            'completed_at' => current_time( 'mysql', true ),
        ];
        if ( null !== $score ) {
            $data['score'] = min( 100, max( 0, $score ) );
        }

        if ( $existing ) {
            // Skip re-marking if already completed (unless it's a quiz re-take).
            if ( 'completed' === $existing->status && null === $score ) {
                return true;
            }
            $result = $wpdb->update( $table, $data, [ 'id' => (int) $existing->id ], null, [ '%d' ] );
        } else {
            $data['status'] = 'completed'; // new row
            $result = $wpdb->insert( $table, $data );
        }

        if ( false !== $result ) {
            do_action( 'fg_lms_lesson_completed', $user_id, $course_id, $lesson_id );
            $this->maybe_complete_course( $user_id, $course_id );
        }

        return false !== $result;
    }

    // ── Course completion check ───────────────────────────────────────────────

    /**
     * Calculates completion % and fires course-completed action if 100%.
     */
    public function maybe_complete_course( int $user_id, int $course_id ): void {
        $pct = $this->get_course_progress( $user_id, $course_id );

        if ( 100 === $pct ) {
            // Mark enrollment complete (idempotent via UPDATE).
            fg_lms()->enrollment->mark_complete( $user_id, $course_id );
        }
    }

    // ── Progress queries ──────────────────────────────────────────────────────

    /**
     * Returns completion percentage (0-100) for a user in a course.
     */
    public function get_course_progress( int $user_id, int $course_id ): int {
        $total     = $this->get_lesson_count( $course_id );
        $completed = $this->get_completed_lesson_count( $user_id, $course_id );

        if ( $total <= 0 ) {
            return 0;
        }
        return (int) min( 100, round( ( $completed / $total ) * 100 ) );
    }

    /**
     * Number of lessons (fg_lesson + fg_quiz) attached to a course.
     */
    public function get_lesson_count( int $course_id ): int {
        return (int) count( $this->get_course_lesson_ids( $course_id ) );
    }

    /**
     * Number of lessons a user has completed in a course.
     */
    public function get_completed_lesson_count( int $user_id, int $course_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}fg_lms_progress
                  WHERE user_id = %d AND course_id = %d AND status = 'completed'",
                $user_id,
                $course_id
            )
        );
    }

    /**
     * Returns all lesson/quiz post IDs attached to a course (via post_meta order).
     *
     * @return int[]
     */
    public function get_course_lesson_ids( int $course_id ): array {
        $raw = get_post_meta( $course_id, '_fg_lms_lesson_order', true );
        if ( ! is_array( $raw ) || empty( $raw ) ) {
            // Fallback: query by parent meta.
            $posts = get_posts( [
                'post_type'      => [ 'fg_lesson', 'fg_quiz' ],
                'meta_key'       => '_fg_lms_course_id',
                'meta_value'     => $course_id,
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'orderby'        => 'menu_order',
                'order'          => 'ASC',
            ] );
            return array_map( 'intval', $posts );
        }
        return array_map( 'intval', $raw );
    }

    /**
     * Has the user completed a specific lesson?
     */
    public function is_lesson_completed( int $user_id, int $lesson_id ): bool {
        global $wpdb;
        return (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}fg_lms_progress
                  WHERE user_id = %d AND lesson_id = %d AND status = 'completed'",
                $user_id,
                $lesson_id
            )
        );
    }

    /**
     * Full progress rows for a user in a course.
     *
     * @return object[]
     */
    public function get_user_course_progress( int $user_id, int $course_id ): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_progress
                  WHERE user_id = %d AND course_id = %d
                  ORDER BY lesson_id ASC",
                $user_id,
                $course_id
            )
        );
    }

    /**
     * Admin: progress overview for all students in a course.
     *
     * @return object[]
     */
    public function get_course_progress_overview( int $course_id ): array {
        global $wpdb;
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT u.ID AS user_id, u.display_name, u.user_email,
                        COUNT(p.id) AS completed_lessons,
                        MAX(p.completed_at) AS last_activity
                   FROM {$wpdb->prefix}fg_lms_enrollments e
                   JOIN {$wpdb->users} u ON u.ID = e.user_id
                   LEFT JOIN {$wpdb->prefix}fg_lms_progress p
                        ON p.user_id = e.user_id AND p.course_id = e.course_id
                        AND p.status = 'completed'
                  WHERE e.course_id = %d
                  GROUP BY u.ID
                  ORDER BY u.display_name ASC",
                $course_id
            )
        );
    }
}
