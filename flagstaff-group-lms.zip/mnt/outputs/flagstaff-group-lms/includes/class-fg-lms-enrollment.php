<?php
/**
 * Course enrollment management.
 *
 * An enrollment is created when a user gains access to a specific course
 * (either manually by an admin, or automatically on subscription).
 *
 * @package FG_LMS
 */

defined( 'ABSPATH' ) || exit;

class FG_LMS_Enrollment {

    // ── Enroll / Unenroll ─────────────────────────────────────────────────────

    /**
     * Enroll a user in a course.
     *
     * @return int|false  Enrollment ID or false if already enrolled / failure.
     */
    public function enroll( int $user_id, int $course_id ): int|false {
        global $wpdb;

        // Already enrolled?
        if ( $this->is_enrolled( $user_id, $course_id ) ) {
            return false;
        }

        $result = $wpdb->insert(
            $wpdb->prefix . 'fg_lms_enrollments',
            [
                'user_id'     => $user_id,
                'course_id'   => $course_id,
                'status'      => 'active',
                'enrolled_at' => current_time( 'mysql', true ),
            ],
            [ '%d', '%d', '%s', '%s' ]
        );

        if ( ! $result ) {
            return false;
        }

        $enrollment_id = (int) $wpdb->insert_id;

        /**
         * @param int $user_id
         * @param int $course_id
         * @param int $enrollment_id
         */
        do_action( 'fg_lms_user_enrolled', $user_id, $course_id, $enrollment_id );

        return $enrollment_id;
    }

    public function unenroll( int $user_id, int $course_id ): bool {
        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . 'fg_lms_enrollments',
            [ 'user_id' => $user_id, 'course_id' => $course_id ],
            [ '%d', '%d' ]
        );
        if ( $result ) {
            do_action( 'fg_lms_user_unenrolled', $user_id, $course_id );
        }
        return (bool) $result;
    }

    // ── Status checks ─────────────────────────────────────────────────────────

    public function is_enrolled( int $user_id, int $course_id ): bool {
        global $wpdb;
        return (bool) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}fg_lms_enrollments
                  WHERE user_id = %d AND course_id = %d
                  LIMIT 1",
                $user_id,
                $course_id
            )
        );
    }

    public function mark_complete( int $user_id, int $course_id ): bool {
        global $wpdb;
        $result = $wpdb->update(
            $wpdb->prefix . 'fg_lms_enrollments',
            [
                'status'       => 'completed',
                'completed_at' => current_time( 'mysql', true ),
            ],
            [ 'user_id' => $user_id, 'course_id' => $course_id ],
            [ '%s', '%s' ],
            [ '%d', '%d' ]
        );

        if ( $result ) {
            do_action( 'fg_lms_course_completed', $user_id, $course_id );
        }

        return (bool) $result;
    }

    /** @return object|null */
    public function get_enrollment( int $user_id, int $course_id ): ?object {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}fg_lms_enrollments
                  WHERE user_id = %d AND course_id = %d",
                $user_id,
                $course_id
            )
        );
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    /**
     * Get all enrollments for a user.
     *
     * @return object[]
     */
    public function get_user_enrollments( int $user_id, string $status = '' ): array {
        global $wpdb;
        $sql = "SELECT e.*, p.post_title AS course_title
                  FROM {$wpdb->prefix}fg_lms_enrollments e
                  JOIN {$wpdb->posts} p ON p.ID = e.course_id
                 WHERE e.user_id = %d";

        $params = [ $user_id ];

        if ( $status ) {
            $sql     .= ' AND e.status = %s';
            $params[] = $status;
        }

        $sql .= ' ORDER BY e.enrolled_at DESC';

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
    }

    /**
     * Get all enrollments for a course (for admin reporting).
     *
     * @return object[]
     */
    public function get_course_enrollments( int $course_id, string $status = '' ): array {
        global $wpdb;
        $sql = "SELECT e.*, u.user_login, u.user_email, u.display_name
                  FROM {$wpdb->prefix}fg_lms_enrollments e
                  JOIN {$wpdb->users} u ON u.ID = e.user_id
                 WHERE e.course_id = %d";

        $params = [ $course_id ];

        if ( $status ) {
            $sql     .= ' AND e.status = %s';
            $params[] = $status;
        }

        $sql .= ' ORDER BY e.enrolled_at DESC';

        // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
    }

    /**
     * Total enrolled students across all courses (for dashboard widget).
     */
    public function total_enrollments(): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}fg_lms_enrollments"
        );
    }
}
