===Flagstaff Group LMS ===
Contributors: flagstaffgroup
Tags: lms, learning management system, courses, memberships, certificates, elearning
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A full-featured Learning Management System branded for Flagstaff Group. Create courses, track student progress, manage memberships, and auto-issue certificates.

== Description ==

Flagstaff Group LMS is a powerful, branded learning management system for WordPress. Similar in scope to LearnDash, it provides:

* **Course Builder** — Drag-and-drop lesson/quiz ordering inside the WordPress editor
* **Memberships & Subscriptions** — Create plans (Free, Paid, Lifetime) that control access to course libraries
* **Student Progress Tracking** — Per-lesson completion, quiz scores, and course-level progress percentages
* **Certificates** — Automatically issued branded HTML certificates on course completion, printable and downloadable
* **Enrollment Management** — Enroll students manually or let them enroll themselves through membership access
* **Admin Reports** — Per-course student progress overview with certificate links
* **Shortcodes** — Embed catalog, dashboard, progress bars, and enroll buttons anywhere

== Shortcodes ==

| Shortcode | Description |
|---|---|
| `[fg_lms_catalog]` | Renders the full course catalog grid |
| `[fg_lms_dashboard]` | Renders the logged-in student's personal dashboard |
| `[fg_lms_course_progress]` | Renders a progress bar for the current/specified course |
| `[fg_lms_enroll_button]` | Smart CTA button (Enroll / Continue / Login / Plan) |

== Installation ==

1. Upload the `flagstaff-group-lms` folder to `/wp-content/plugins/`
2. Activate the plugin through **Plugins > Installed Plugins**
3. Go to **Flagstaff LMS > Settings** to configure branding and page assignments
4. Create pages with the relevant shortcodes (`[fg_lms_catalog]`, `[fg_lms_dashboard]`)
5. Create your first course via **Flagstaff LMS > Courses > New Course**

== Changelog ==

= 1.0.0 =
* Initial release

== Upgrade Notice ==

= 1.0.0 =
First release.
